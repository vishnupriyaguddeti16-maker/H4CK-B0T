import logging
from pathlib import Path


def setup_logger(config):
    """Create a centralized console and file logger for the application."""
    log_config = config.get("logging", {})
    level_name = (log_config.get("level") or "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    log_dir = Path(__file__).resolve().parents[1]
    app_log_path = (log_dir / (log_config.get("file") or "logs/h4ckbot.log")).resolve()
    audit_log_path = (log_dir / (log_config.get("audit_log") or "logs/h4ckbot_audit.log")).resolve()

    app_log_path.parent.mkdir(parents=True, exist_ok=True)
    audit_log_path.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("h4ckbot")
    logger.setLevel(level)
    logger.handlers.clear()

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = logging.FileHandler(app_log_path, encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    audit_logger = logging.getLogger("h4ckbot.audit")
    audit_logger.setLevel(logging.INFO)
    audit_logger.handlers.clear()

    audit_handler = logging.FileHandler(audit_log_path, encoding="utf-8")
    audit_handler.setFormatter(formatter)
    audit_logger.addHandler(audit_handler)

    logger.audit_logger = audit_logger
    return logger
