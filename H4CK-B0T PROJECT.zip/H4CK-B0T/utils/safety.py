import http.client
import ipaddress
import socket
import ssl
import time
from functools import partial
from urllib.error import HTTPError
from urllib.parse import urlparse, urlunparse
from urllib.request import (
    HTTPHandler,
    HTTPRedirectHandler,
    HTTPSHandler,
    ProxyHandler,
    build_opener,
)


_RATE_TRACKER = {}


def normalize_target(target):
    """Normalize the target string and validate the basic URL structure."""
    if not isinstance(target, str):
        raise ValueError("Target must be a string.")

    normalized = target.strip()
    if not normalized:
        raise ValueError("Target URL cannot be empty.")

    reject_url_credentials(normalized)
    parsed = urlparse(normalized)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise ValueError("Only http and https targets are allowed.")
    if not parsed.netloc:
        raise ValueError("Target URL must include a domain name.")

    return normalized


def reject_url_credentials(target):
    """Reject URL user information without including it in the error message."""
    if not isinstance(target, str):
        return

    try:
        parsed = urlparse(target.strip())
    except ValueError:
        return

    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Target URL must not contain username or password information.")


def canonicalize_target(target):
    """Canonicalize URL forms that identify the same HTTP endpoint."""
    parsed = urlparse(normalize_target(target))
    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Target URL must include a domain name.")

    scheme = parsed.scheme.lower()
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError("Target URL contains an invalid port.") from exc

    default_port = {"http": 80, "https": 443}[scheme]
    host = hostname.lower()
    if ":" in host:
        host = f"[{host}]"
    if port is not None and port != default_port:
        host = f"{host}:{port}"

    userinfo = parsed.netloc.rsplit("@", 1)[0] + "@" if "@" in parsed.netloc else ""
    return urlunparse((scheme, f"{userinfo}{host}", parsed.path or "/", parsed.params, parsed.query, ""))


def _effective_port(parsed):
    try:
        port = parsed.port
    except ValueError:
        return None
    return port if port is not None else {"http": 80, "https": 443}.get(parsed.scheme.lower())


def is_authorized_target(target, config):
    """Return True only when the target appears in the authorized allowlist."""
    normalized = normalize_target(target)
    authorized = config.get("authorized_targets", [])
    candidates = [normalize_target(item) for item in authorized]
    return normalized in candidates


def is_denylisted(target, config):
    """Return True when the target is explicitly blocked."""
    normalized = canonicalize_target(target)
    denylist = config.get("denylist", [])
    for item in denylist:
        try:
            if canonicalize_target(item) == normalized:
                return True
        except ValueError:
            continue
    return False


def validate_scope(target, config):
    """Require explicit authorization regardless of the safe-mode setting."""
    return is_authorized_target(target, config)


def is_same_host_authorized(target, config):
    """Allow only the same host and scheme as an explicitly authorized target."""
    normalized = normalize_target(target)
    parsed = urlparse(normalized)
    authorized = config.get("authorized_targets", [])

    for item in authorized:
        try:
            candidate = normalize_target(item)
            candidate_parsed = urlparse(candidate)
            parsed_port = _effective_port(parsed)
            candidate_port = _effective_port(candidate_parsed)
            if (
                parsed.scheme.lower() == candidate_parsed.scheme.lower()
                and parsed.hostname is not None
                and candidate_parsed.hostname is not None
                and parsed.hostname.lower() == candidate_parsed.hostname.lower()
                and parsed_port is not None
                and parsed_port == candidate_port
            ):
                return True
        except ValueError:
            continue

    return False


def _resolve_addresses(host, port):
    """Resolve a hostname once and return its unique IP addresses."""
    try:
        return [ipaddress.ip_address(host)]
    except ValueError:
        pass

    addresses = []
    for result in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM):
        address = ipaddress.ip_address(result[4][0])
        if address not in addresses:
            addresses.append(address)
    if not addresses:
        raise ValueError("Target hostname did not resolve to an IP address.")
    return addresses


def _is_supported_global_address(address):
    """Reject non-global and special-purpose addresses from assessment requests."""
    if (
        not address.is_global
        or address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_multicast
        or address.is_reserved
        or address.is_unspecified
    ):
        return False

    special_networks = (
        (
            "192.0.0.0/24",
            "192.31.196.0/24",
            "192.52.193.0/24",
            "192.88.99.0/24",
            "192.175.48.0/24",
        )
        if address.version == 4
        else (
            "64:ff9b::/96",
            "64:ff9b:1::/48",
            "2001::/23",
            "2001:db8::/32",
            "2002::/16",
            "2620:4f:8000::/48",
            "3fff::/20",
        )
    )
    if address.version == 6 and address.ipv4_mapped is not None:
        return False
    return not any(address in ipaddress.ip_network(network) for network in special_networks)


def _validated_address_for_url(target, scope_target, config):
    parsed = urlparse(normalize_target(target))
    host = parsed.hostname
    if not host:
        raise ValueError("Target URL must include a domain name.")

    port = _effective_port(parsed)
    if port is None:
        raise ValueError("Target URL contains an invalid port.")

    addresses = _resolve_addresses(host, port)
    scope_host = urlparse(normalize_target(scope_target)).hostname
    try:
        scope_address = ipaddress.ip_address(scope_host) if scope_host else None
    except ValueError:
        scope_address = None
    explicit_loopback_scope = (
        is_authorized_target(scope_target, config)
        and (
            (scope_address is not None and scope_address.is_loopback)
            or (scope_host is not None and scope_host.lower() == "localhost")
        )
    )

    if explicit_loopback_scope:
        if not all(address.is_loopback for address in addresses):
            raise ValueError("Target hostname resolved outside explicitly authorized loopback scope.")
    elif not all(_is_supported_global_address(address) for address in addresses):
        raise ValueError("Target hostname resolved to a non-global or special-purpose IP address.")

    return str(addresses[0])


def _connect_pinned(address, port, timeout, source_address):
    """Connect directly to a validated numeric address without resolving the hostname."""
    ip_address = ipaddress.ip_address(address)
    family = socket.AF_INET6 if ip_address.version == 6 else socket.AF_INET
    connection = socket.socket(family, socket.SOCK_STREAM)
    try:
        if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
            connection.settimeout(timeout)
        if source_address:
            connection.bind(source_address)
        sockaddr = (
            (str(ip_address), port, 0, 0)
            if ip_address.version == 6
            else (str(ip_address), port)
        )
        connection.connect(sockaddr)
        return connection
    except Exception:
        connection.close()
        raise


class _PinnedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host, pinned_address, **kwargs):
        super().__init__(host, **kwargs)
        self._pinned_address = pinned_address

    def connect(self):
        if self._tunnel_host:
            raise OSError("Proxy tunnels are not supported for pinned assessment requests.")
        self.sock = _connect_pinned(
            self._pinned_address, self.port, self.timeout, self.source_address
        )


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, pinned_address, **kwargs):
        super().__init__(host, **kwargs)
        self._pinned_address = pinned_address

    def connect(self):
        if self._tunnel_host:
            raise OSError("Proxy tunnels are not supported for pinned assessment requests.")
        sock = _connect_pinned(
            self._pinned_address, self.port, self.timeout, self.source_address
        )
        try:
            if self._context is None:
                self._context = ssl._create_default_https_context()
            server_hostname = self.host if self._context.check_hostname else None
            self.sock = self._context.wrap_socket(sock, server_hostname=server_hostname)
        except Exception:
            sock.close()
            raise


class _PinnedHTTPHandler(HTTPHandler):
    def __init__(self, scope_target, config, debuglevel=0):
        super().__init__(debuglevel=debuglevel)
        self.scope_target = scope_target
        self.config = config

    def http_open(self, request):
        address = _validated_address_for_url(
            request.full_url, self.scope_target, self.config
        )
        factory = partial(_PinnedHTTPConnection, pinned_address=address)
        return self.do_open(factory, request)


class _PinnedHTTPSHandler(HTTPSHandler):
    def __init__(self, scope_target, config, debuglevel=0, context=None, check_hostname=None):
        super().__init__(debuglevel, context, check_hostname)
        self.scope_target = scope_target
        self.config = config

    def https_open(self, request):
        address = _validated_address_for_url(
            request.full_url, self.scope_target, self.config
        )
        factory = partial(_PinnedHTTPSConnection, pinned_address=address)
        return self.do_open(
            factory,
            request,
            context=self._context,
            check_hostname=self._check_hostname,
        )


def validate_discovery_scope(target, config):
    """Allow discovery only within the explicitly authorized host scope."""
    normalized = normalize_target(target)
    if not is_authorized_target(normalized, config):
        raise ValueError(
            f"Target not authorized: {normalized}. This system only accepts explicitly authorized targets."
        )
    if is_denylisted(normalized, config):
        raise ValueError(f"Target is denylisted: {normalized}")
    if not is_same_host_authorized(normalized, config):
        raise ValueError(
            f"Target is outside the same-host discovery scope: {normalized}"
        )
    return normalized


def check_rate_limit(target, config):
    """Simple rate limiting to prevent excessive repeated requests."""
    limit = int(config.get("request_rate_limit", 0) or 0)
    window = int(config.get("rate_window_seconds", 60) or 60)

    if limit <= 0:
        return

    key = canonicalize_target(target)
    now = time.time()
    history = _RATE_TRACKER.setdefault(key, [])
    history[:] = [timestamp for timestamp in history if now - timestamp < window]

    if len(history) >= limit:
        raise PermissionError(
            "Rate limit exceeded for this target. Please wait before running another scan."
        )

    history.append(now)


def audit_event(logger, event_type, message, target=None):
    """Log an audit message for security assessment actions."""
    if logger is None:
        return
    target_text = f" Target: {target}" if target else ""
    logger.info("%s%s - %s", event_type, target_text, message)


def same_host_allowed(target, candidate, config=None):
    """Return True when the candidate is within the same host and scheme as the authorized target."""
    config = config or {}
    normalized_target = normalize_target(target)
    normalized_candidate = normalize_target(candidate)

    root_parsed = urlparse(normalized_target)
    candidate_parsed = urlparse(normalized_candidate)

    if root_parsed.scheme.lower() != candidate_parsed.scheme.lower():
        return False
    if not root_parsed.hostname or not candidate_parsed.hostname:
        return False
    if root_parsed.hostname.lower() != candidate_parsed.hostname.lower():
        return False
    root_port = _effective_port(root_parsed)
    candidate_port = _effective_port(candidate_parsed)
    if root_port is None or candidate_port is None or root_port != candidate_port:
        return False
    if candidate_parsed.username is not None or candidate_parsed.password is not None:
        return False
    if is_denylisted(normalized_candidate, config):
        return False
    return True


class ScopedRedirectHandler(HTTPRedirectHandler):
    """Reject redirects outside the validated host, scheme, port, and denylist scope."""

    def __init__(self, scope_target, config=None):
        super().__init__()
        self.scope_target = scope_target
        self.config = config or {}

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not same_host_allowed(self.scope_target, newurl, self.config):
            raise HTTPError(newurl, code, "Redirect outside the authorized scope", headers, fp)
        check_rate_limit(newurl, self.config)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def open_scoped_url(target, scope_target, config=None, timeout=5):
    """Open an HTTP URL while validating every redirect before following it."""
    config = config or {}
    if not is_authorized_target(scope_target, config):
        raise ValueError(f"Target is not explicitly authorized: {scope_target}")
    if not is_same_host_authorized(scope_target, config):
        raise ValueError(f"Target is not within an authorized host scope: {scope_target}")
    if not same_host_allowed(scope_target, target, config):
        raise ValueError(f"Target is outside the authorized scope: {target}")

    check_rate_limit(target, config)
    opener = build_opener(
        ProxyHandler({}),
        _PinnedHTTPHandler(scope_target, config),
        _PinnedHTTPSHandler(scope_target, config),
        ScopedRedirectHandler(scope_target, config),
    )
    response = opener.open(target, timeout=timeout)
    final_url = response.geturl()
    if not same_host_allowed(scope_target, final_url, config):
        response.close()
        raise ValueError(f"Response URL is outside the authorized scope: {final_url}")
    return response


def build_same_host_candidates(target, config=None):
    """Generate a safe list of same-host candidate URLs for the authorized target."""
    config = config or {}
    normalized_target = normalize_target(target)
    parsed = urlparse(normalized_target)
    base_url = f"{parsed.scheme}://{parsed.netloc}"

    extra_paths = config.get("discovery_paths") or ["/", "/about", "/contact", "/login"]
    candidates = [normalized_target]
    seen = {normalized_target}

    for item in extra_paths:
        if item is None:
            continue
        if not isinstance(item, str):
            continue

        path_value = item.strip()
        if not path_value:
            continue

        if "://" in path_value:
            candidate = normalize_target(path_value)
        else:
            if not path_value.startswith("/"):
                path_value = f"/{path_value}"
            candidate = normalize_target(f"{base_url}{path_value}")

        if candidate in seen:
            continue
        if is_denylisted(candidate, config):
            continue
        if not same_host_allowed(normalized_target, candidate, config):
            continue

        seen.add(candidate)
        candidates.append(candidate)

    return candidates


def validate_target(target, config):
    """Authorize and validate a target before scanning or reporting."""
    normalized = normalize_target(target)

    if not is_authorized_target(normalized, config):
        raise ValueError(
            f"Target not authorized: {normalized}. This system only accepts explicitly authorized targets."
        )

    if is_denylisted(normalized, config):
        raise ValueError(f"Target is denylisted: {normalized}")

    if not validate_scope(normalized, config):
        raise ValueError(f"Target is outside the approved scope: {normalized}")

    return normalized
