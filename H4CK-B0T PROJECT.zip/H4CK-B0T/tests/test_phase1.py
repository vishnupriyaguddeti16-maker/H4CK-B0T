import json
import os
import app as dashboard_app
import main as legacy_discovery
import run as app_run
import runpy
import sys
from email.message import Message
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.request import Request

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from modules import discovery, scanner, validation, evidence, risk, correlation, report
from utils import safety
from utils.safety import ScopedRedirectHandler, validate_target, is_authorized_target, is_denylisted, validate_scope
from utils.logger import setup_logger


PROJECT_ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(autouse=True)
def isolate_stage_result_outputs(monkeypatch, tmp_path):
    isolated_results = tmp_path / "isolated_stage_results"
    for module in (
        discovery,
        scanner,
        validation,
        evidence,
        risk,
        correlation,
        report,
    ):
        monkeypatch.setattr(module, "RESULTS_DIR", isolated_results)


def _resolve_json_pointer(document, pointer):
    value = document
    for token in pointer.lstrip('/').split('/'):
        token = token.replace('~1', '/').replace('~0', '~')
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def test_configuration_loading():
    cfg_path = PROJECT_ROOT / 'config' / 'config.yaml'
    assert cfg_path.exists(), 'config.yaml should exist for Phase 1'

    with open(cfg_path, 'r', encoding='utf-8') as handle:
        data = handle.read()
        assert 'authorized_targets' in data
        assert 'safe_mode' in data


def test_authorized_target_accepted():
    target = 'https://example.com'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'rate_limit': 0,
    }
    assert is_authorized_target(target, config) is True


@pytest.mark.parametrize('safe_mode', [True, False])
def test_unauthorized_target_rejected(safe_mode):
    target = 'https://example.org'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
        'rate_limit': 0,
    }

    with pytest.raises(ValueError, match='Target not authorized'):
        validate_target(target, config)


@pytest.mark.parametrize('safe_mode', [True, False])
@pytest.mark.parametrize(
    'target',
    [
        'https://alice:secret@example.com',
        'https://alice@example.com',
        'https://:secret@example.com',
    ],
)
def test_allowlisted_target_with_credentials_is_rejected_without_disclosure(
    target, safe_mode
):
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': safe_mode,
    }

    with pytest.raises(ValueError, match='username or password') as exc_info:
        validate_target(target, config)

    assert 'alice' not in str(exc_info.value)
    assert 'secret' not in str(exc_info.value)


def test_denylisted_target_rejected():
    target = 'https://example.com'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': ['https://example.com'],
        'safe_mode': True,
        'rate_limit': 0,
    }
    try:
        validate_target(target, config)
        assert False, 'denylisted target should raise an exception'
    except ValueError:
        pass


@pytest.mark.parametrize('safe_mode', [True, False])
def test_scope_requires_allowlist_regardless_of_safe_mode(safe_mode):
    config = {'safe_mode': safe_mode, 'authorized_targets': ['https://example.com'], 'denylist': []}
    assert validate_scope('https://example.com', config) is True
    assert validate_scope('https://example.org', config) is False


def test_same_host_discovery_scope_allowed():
    config = {'safe_mode': True, 'authorized_targets': ['https://example.com'], 'denylist': []}
    assert validate_target('https://example.com', config) == 'https://example.com'


def test_cross_host_discovery_scope_rejected():
    config = {'safe_mode': True, 'authorized_targets': ['https://example.com'], 'denylist': []}
    try:
        validate_target('https://example.org', config)
        assert False, 'cross-host target should be rejected'
    except ValueError:
        pass


def test_security_header_baseline_expansion(monkeypatch):
    class FakeResponse:
        headers = {
            'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
            'Referrer-Policy': 'unsafe-url',
            'Permissions-Policy': 'geolocation=*, camera=()',
            'Cross-Origin-Opener-Policy': 'unsafe-none',
            'Set-Cookie': ['sessionid=abc; Secure; HttpOnly; SameSite=Lax', 'csrf=xyz; HttpOnly; SameSite=None'],
        }

        @staticmethod
        def get_all(name):
            if name == 'Set-Cookie':
                return ['sessionid=abc; Secure; HttpOnly; SameSite=Lax', 'csrf=xyz; HttpOnly; SameSite=None']
            return []

        def get(self, key, default=None):
            return self.headers.get(key, default)

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse()

    monkeypatch.setattr(scanner, 'open_scoped_url', fake_open_scoped_url)

    result = scanner.run_scan('https://example.com', {'timeout_seconds': 5, 'authorized_targets': ['https://example.com']}, logger=None)

    assert result['headers']['Strict-Transport-Security'] == 'PRESENT'
    assert result['headers']['Referrer-Policy'] == 'WEAK VALUE'
    assert result['headers']['Permissions-Policy'] == 'WEAK VALUE'
    assert result['headers']['Cross-Origin-Opener-Policy'] == 'WEAK VALUE'
    assert result['headers']['Set-Cookie'] == 'WEAK VALUE'

    validation_result = validation.run_validation(result, {'safe_mode': True}, logger=None)
    findings = {item['Finding name']: item['Validation status'] for item in validation_result['findings']}
    assert findings['Referrer-Policy'] == 'Potential Finding'
    assert findings['Permissions-Policy'] == 'Potential Finding'
    assert findings['Cross-Origin-Opener-Policy'] == 'Potential Finding'
    assert findings['Set-Cookie'] == 'Potential Finding'


def test_basic_pipeline_execution(monkeypatch, tmp_path):
    target = 'https://example.com'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'request_rate_limit': 0,
        'timeout_seconds': 5,
        'logging': {
            'level': 'INFO',
            'file': str(tmp_path / 'h4ckbot.log'),
            'audit_log': str(tmp_path / 'audit.log'),
        },
    }

    class FakeResponse:
        status = 200
        headers = {
            'Content-Security-Policy': "default-src 'self'",
            'X-Frame-Options': 'DENY',
            'X-Content-Type-Options': 'nosniff',
            'Server': 'test-server',
            'Content-Type': 'text/html',
        }

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, received_config, timeout):
        assert received_config is config
        assert timeout == 5
        return FakeResponse(url)

    for module in (discovery, scanner, validation, evidence, risk, correlation, report):
        monkeypatch.setattr(module, 'RESULTS_DIR', tmp_path / 'results')
    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(scanner, 'open_scoped_url', fake_open_scoped_url)

    logger = setup_logger(config)
    discovery_data = discovery.run_discovery(target, config, logger)
    scan_data = scanner.run_scan(target, config, logger)
    validation_data = validation.run_validation(scan_data, config, logger)
    evidence_data = evidence.collect_evidence(discovery_data, scan_data, validation_data, config, logger)
    risk_data = risk.calculate_risk(validation_data, config, logger)
    correlation_data = correlation.correlate_findings(discovery_data, validation_data, risk_data, config, logger)
    report_data = report.generate_report(target, discovery_data, scan_data, validation_data, evidence_data, risk_data, correlation_data, config, logger)

    assert discovery_data['target'] == target
    assert scan_data['target'] == target
    assert validation_data['target'] == target
    assert isinstance(report_data, dict)
    assert isinstance(risk_data, dict)
    assert isinstance(correlation_data, dict)

    results_dir = tmp_path / 'results'
    assert results_dir.exists()

    for file_name in [
        'discovery_result.json',
        'scan_result.json',
        'validation_result.json',
        'evidence_result.json',
        'risk_result.json',
        'correlation_result.json',
        'report.json',
    ]:
        path = results_dir / file_name
        assert path.exists(), f'{file_name} was not created'


def test_same_host_discovery_expands_only_within_authorized_host(monkeypatch):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'text/html', 'Server': 'test-server'}

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        response = FakeResponse()
        response.url = url
        return response

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)

    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'rate_limit': 0,
        'discovery_paths': ['/', '/about', '/contact', 'https://example.org/blockme'],
        'timeout_seconds': 5,
    }

    result = discovery.run_discovery('https://example.com', config, logger=None)
    discovered = {entry['url'] for entry in result['discovered_endpoints']}

    assert 'https://example.com/' in discovered
    assert 'https://example.com/about' in discovered
    assert 'https://example.com/contact' in discovered
    assert 'https://example.org/blockme' not in discovered


def test_discovery_inventory_always_includes_authorized_root_target(monkeypatch):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'text/html', 'Server': 'test-server'}

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        response = FakeResponse()
        response.url = url
        return response

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)

    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'rate_limit': 0,
        'discovery_paths': ['/about', '/contact'],
        'timeout_seconds': 5,
    }

    result = discovery.run_discovery('https://example.com', config, logger=None)
    urls = [entry['url'] for entry in result['discovered_endpoints']]

    assert result['target'] in urls
    assert urls[0] == result['target']
    assert 'https://example.com/about' in urls
    assert 'https://example.com/contact' in urls


def test_discovery_inventory_records_reachable_metadata(monkeypatch):
    class FakeResponse:
        status = 200
        headers = {
            'Content-Type': 'application/json',
            'Server': 'test-server',
            'X-Test-Header': 'present',
        }

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)

    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'rate_limit': 0,
        'discovery_paths': ['/about'],
        'timeout_seconds': 5,
    }

    result = discovery.run_discovery('https://example.com', config, logger=None)
    record = next(entry for entry in result['discovered_endpoints'] if entry['url'] == 'https://example.com/about')

    assert record['reachable'] is True
    assert record['status_code'] == 200
    assert record['final_url'] == 'https://example.com/about'
    assert record['server'] == 'test-server'
    assert record['content_type'] == 'application/json'
    assert record['headers']['X-Test-Header'] == 'present'


def test_discovery_classifies_authorized_root_target(monkeypatch, tmp_path):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'text/html'}

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        response = FakeResponse()
        response.url = url
        return response

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': [],
        },
        logger=None,
    )
    root = result['discovered_endpoints'][0]

    assert root['url'] == result['target']
    assert root['classifications'] == [
        'Authorized root target',
        'Reachable HTTP endpoint',
        'Web content',
    ]


@pytest.mark.parametrize(
    ('content_type', 'expected_classification'),
    [
        ('text/html; charset=utf-8', 'Web content'),
        ('application/json; charset=utf-8', 'JSON content'),
    ],
)
def test_discovery_classifies_reachable_content_type(
    monkeypatch, tmp_path, content_type, expected_classification
):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': content_type}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/content'],
        },
        logger=None,
    )
    candidate = next(
        entry for entry in result['discovered_endpoints']
        if entry['url'] == 'https://example.com/content'
    )

    assert expected_classification in candidate['classifications']
    assert 'Reachable HTTP endpoint' in candidate['classifications']


def test_discovery_classifies_api_path_with_json_without_changing_metadata(
    monkeypatch, tmp_path
):
    calls = []

    class FakeResponse:
        status = 200
        headers = {
            'Content-Type': 'application/json; charset=utf-8',
            'Server': 'example-server',
            'X-Test-Header': 'present',
        }

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        calls.append(url)
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/api/v1/users'],
        },
        logger=None,
    )
    root, api_endpoint = result['discovered_endpoints']

    assert calls == ['https://example.com', 'https://example.com/api/v1/users']
    assert len(calls) == len(result['discovered_endpoints'])
    assert root['url'] == 'https://example.com'
    assert root['classifications'] == [
        'Authorized root target',
        'Reachable HTTP endpoint',
        'JSON content',
    ]
    assert root['status_code'] == 200
    assert root['final_url'] == 'https://example.com'
    assert root['server'] == 'example-server'
    assert root['content_type'] == 'application/json; charset=utf-8'
    assert root['headers'] == FakeResponse.headers
    assert api_endpoint['url'] == 'https://example.com/api/v1/users'
    assert api_endpoint['classifications'] == [
        'Reachable HTTP endpoint',
        'JSON content',
        'Possible API endpoint',
    ]
    assert api_endpoint['status_code'] == 200
    assert api_endpoint['final_url'] == api_endpoint['url']
    assert api_endpoint['server'] == 'example-server'
    assert api_endpoint['content_type'] == 'application/json; charset=utf-8'
    assert api_endpoint['headers'] == FakeResponse.headers


def test_discovery_does_not_classify_normal_json_path_as_possible_api(
    monkeypatch, tmp_path
):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'application/json'}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/users'],
        },
        logger=None,
    )
    endpoint = result['discovered_endpoints'][1]

    assert endpoint['classifications'] == [
        'Reachable HTTP endpoint',
        'JSON content',
    ]


def test_discovery_does_not_classify_api_path_with_non_json_content(
    monkeypatch, tmp_path
):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'text/html; charset=utf-8'}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/api/v1/users'],
        },
        logger=None,
    )
    endpoint = result['discovered_endpoints'][1]

    assert endpoint['classifications'] == [
        'Reachable HTTP endpoint',
        'Web content',
    ]


def test_discovery_classifies_unreachable_endpoint(monkeypatch, tmp_path):
    calls = []

    def failed_open_scoped_url(url, scope_target, config, timeout):
        calls.append(url)
        if url.endswith('/unreachable'):
            raise OSError('mocked connection failure')
        raise OSError('mocked connection failure')

    monkeypatch.setattr(discovery, 'open_scoped_url', failed_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/unreachable'],
        },
        logger=None,
    )
    unreachable = next(
        entry for entry in result['discovered_endpoints']
        if entry['url'] == 'https://example.com/unreachable'
    )

    assert unreachable['reachable'] is False
    assert unreachable['classifications'] == ['Unreachable endpoint']


def test_discovery_preserves_server_metadata_without_fingerprinting(monkeypatch, tmp_path):
    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'text/plain', 'Server': 'example-server'}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/plain'],
        },
        logger=None,
    )
    record = next(
        entry for entry in result['discovered_endpoints']
        if entry['url'] == 'https://example.com/plain'
    )

    assert record['server'] == 'example-server'
    assert 'Server' in record['headers']
    assert 'Web content' in record['classifications']
    assert not any(
        'framework' in classification.lower()
        or 'cms' in classification.lower()
        or 'technology' in classification.lower()
        for classification in record['classifications']
    )


def test_discovery_classification_does_not_make_additional_requests(monkeypatch, tmp_path):
    calls = []

    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'application/json'}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        calls.append(url)
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': ['/one', '/two'],
        },
        logger=None,
    )

    assert len(calls) == len(result['discovered_endpoints']) == 3


def test_discovery_classification_keeps_candidate_scope_restrictions(
    monkeypatch, tmp_path
):
    calls = []

    class FakeResponse:
        status = 200
        headers = {'Content-Type': 'application/octet-stream'}

        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        calls.append(url)
        return FakeResponse(url)

    monkeypatch.setattr(discovery, 'open_scoped_url', fake_open_scoped_url)
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)

    result = discovery.run_discovery(
        'https://example.com',
        {
            'authorized_targets': ['https://example.com'],
            'denylist': [],
            'discovery_paths': [
                '/in-scope',
                'https://example.org/out-of-scope',
                'http://example.com/wrong-scheme',
                'https://example.com:8443/wrong-port',
            ],
        },
        logger=None,
    )

    inventory_urls = [entry['url'] for entry in result['discovered_endpoints']]
    assert inventory_urls == [
        'https://example.com',
        'https://example.com/in-scope',
    ]
    assert calls == inventory_urls
    assert 'Other HTTP content' in result['discovered_endpoints'][0]['classifications']


@pytest.mark.parametrize(
    'target',
    [
        'https://example.org',
        'http://example.com',
        'https://example.com:8443',
    ],
)
def test_discovery_rejects_out_of_scope_targets(target):
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
        'request_rate_limit': 0,
        'timeout_seconds': 5,
    }

    with pytest.raises(ValueError):
        safety.validate_discovery_scope(target, config)


def test_multi_endpoint_scan_aggregates_endpoint_results(monkeypatch):
    class FakeResponse:
        status = 200
        headers = {
            'Content-Type': 'text/html',
            'Server': 'test-server',
            'Strict-Transport-Security': 'max-age=31536000',
            'Referrer-Policy': 'strict-origin-when-cross-origin',
            'Permissions-Policy': 'geolocation=(), camera=()',
            'Cross-Origin-Opener-Policy': 'same-origin',
            'Set-Cookie': 'sessionid=abc; Secure; HttpOnly; SameSite=Lax',
        }

        def geturl(self):
            return self.url

    def fake_open_scoped_url(url, scope_target, config, timeout):
        response = FakeResponse()
        response.url = url
        return response

    monkeypatch.setattr(scanner, 'open_scoped_url', fake_open_scoped_url)

    endpoints = ['https://example.com/', 'https://example.com/about']
    result = scanner.run_scan(endpoints, {'timeout_seconds': 5, 'authorized_targets': ['https://example.com']}, logger=None)

    assert result['scan_status'] == 'completed'
    assert len(result['endpoints']) == 2
    assert result['summary']['total_endpoints'] == 2
    assert result['summary']['successful_scans'] == 2


def test_endpoint_risk_aggregation_uses_existing_findings():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Referrer-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Strict-Transport-Security', 'Validation status': 'No issue found'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)

    assert 'endpoint_risk_summary' in risk_data
    assert any(item['endpoint'] == 'https://example.com/' for item in risk_data['endpoint_risk_summary'])
    assert any(item['endpoint'] == 'https://example.com/about' for item in risk_data['endpoint_risk_summary'])


def test_endpoint_prioritization_is_deterministic_and_highest_risk_first():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Referrer-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Permissions-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'Strict-Transport-Security', 'Validation status': 'No issue found'},
            {'Endpoint': 'https://example.com/contact', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    ordered = [item['endpoint'] for item in risk_data['prioritized_endpoints']]

    assert ordered[0] == 'https://example.com/about'
    assert ordered[-1] == 'https://example.com/'


def test_low_risk_endpoint_stays_low_risk():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Strict-Transport-Security', 'Validation status': 'No issue found'},
            {'Endpoint': 'https://example.com/contact', 'Finding name': 'X-Frame-Options', 'Validation status': 'No issue found'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    risk_summary = {item['endpoint']: item['risk_level'] for item in risk_data['endpoint_risk_summary']}

    assert risk_summary['https://example.com/'] == 'low'
    assert risk_summary['https://example.com/contact'] == 'low'


def test_high_risk_requires_multiple_provisional_findings():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': header, 'Validation status': 'Potential Finding'}
            for header in [
                'Strict-Transport-Security',
                'Content-Security-Policy',
                'Permissions-Policy',
                'Set-Cookie',
                'X-Frame-Options',
            ]
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    summary = {item['endpoint']: item['risk_level'] for item in risk_data['endpoint_risk_summary']}

    assert summary['https://example.com/'] == 'high'
    assert risk_data['summary']['high_count'] == 5
    assert risk_data['risk_levels']['high']


def test_three_high_impact_findings_on_same_endpoint_are_high_risk():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Strict-Transport-Security', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'Set-Cookie', 'Validation status': 'Potential Finding'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    summary_by_endpoint = {item['endpoint']: item for item in risk_data['endpoint_risk_summary']}

    assert summary_by_endpoint['https://example.com/']['risk_level'] == 'high'
    assert summary_by_endpoint['https://example.com/']['potential_findings'] == 3
    assert risk_data['summary']['high_count'] == 3
    assert risk_data['summary']['medium_count'] == 0
    assert risk_data['risk_levels']['high'] == validation_data['findings']
    assert risk_data['prioritized_endpoints'][0]['endpoint'] == 'https://example.com/'
    assert risk_data['prioritized_endpoints'][0]['risk_level'] == 'high'


def test_final_report_preserves_recommended_remediation_for_header_findings():
    target = 'https://example.com/'
    scan_data = {
        'target': target,
        'headers': {'Strict-Transport-Security': 'NOT FOUND'},
        'scan_status': 'completed',
    }

    validation_data = validation.run_validation(scan_data, {'safe_mode': True}, logger=None)
    report_data = report.generate_report(
        target,
        {'target': target},
        scan_data,
        validation_data,
        {'target': target},
        {'summary': {'high_count': 0, 'medium_count': 1, 'low_count': 0}, 'endpoint_risk_summary': [], 'prioritized_endpoints': []},
        {'target': target, 'risk_summary': {'high_count': 0, 'medium_count': 1, 'low_count': 0}},
        logger=None,
    )

    finding = validation_data['findings'][0]
    assert finding['Validation status'] == 'Potential Finding'
    assert 'Recommended remediation' in finding
    assert 'Strict-Transport-Security' in finding['Recommended remediation']
    assert report_data['validation']['findings'][0]['Recommended remediation'] == finding['Recommended remediation']


def test_missing_evidence_does_not_create_risk_or_prioritization():
    validation_data = {
        'target': 'https://example.com',
        'findings': [],
        'unvalidated_endpoints': [
            {'endpoint': 'https://example.com/unreachable', 'scan_status': 'failed', 'validation_status': 'not_assessed'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)

    assert risk_data['summary'] == {
        'high_count': 0,
        'medium_count': 0,
        'low_count': 0,
        'endpoint_count': 1,
    }
    assert risk_data['endpoint_risk_summary'] == []
    assert risk_data['prioritized_endpoints'] == []
    assert risk_data['risk_levels'] == {'high': [], 'medium': [], 'low': []}


def test_cross_host_and_denylisted_endpoints_do_not_enter_prioritization():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.org/', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/blocked', 'Finding name': 'Referrer-Policy', 'Validation status': 'Potential Finding'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True, 'denylist': ['https://example.com/blocked']}, logger=None)
    endpoints = [item['endpoint'] for item in risk_data['prioritized_endpoints']]

    assert 'https://example.org/' not in endpoints
    assert 'https://example.com/blocked' not in endpoints
    assert 'https://example.com/' in endpoints


def test_report_contains_endpoint_risk_summary():
    target = 'https://example.com'
    discovery_data = {'target': target, 'discovered_endpoints': [{'url': 'https://example.com/'}, {'url': 'https://example.com/about'}]}
    scan_data = {
        'target': target,
        'endpoints': [
            {'target': 'https://example.com/', 'headers': {'Content-Security-Policy': 'NOT FOUND'}},
            {'target': 'https://example.com/about', 'headers': {'Strict-Transport-Security': 'PRESENT'}},
        ],
    }
    validation_data = {
        'target': target,
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Strict-Transport-Security', 'Validation status': 'No issue found'},
        ],
    }
    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    correlation_data = {'target': target, 'risk_summary': risk_data['summary']}
    evidence_data = {'target': target, 'evidence_status': 'collected'}

    report_data = report.generate_report(target, discovery_data, scan_data, validation_data, evidence_data, risk_data, correlation_data, {'safe_mode': True}, logger=None)

    assert 'endpoint_risk_summary' in report_data['risk']
    assert 'prioritized_endpoints' in report_data['risk']
    assert report_data['risk']['prioritized_endpoints'][0]['endpoint'] in {'https://example.com/', 'https://example.com/about'}


def test_cross_host_redirect_is_rejected_before_following():
    handler = ScopedRedirectHandler('https://example.com', {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
    })
    request = Request('https://example.com/')

    with pytest.raises(HTTPError, match='outside the authorized scope'):
        handler.redirect_request(request, BytesIO(), 302, 'Found', Message(), 'https://example.org/landing')
    with pytest.raises(HTTPError, match='outside the authorized scope'):
        handler.redirect_request(request, BytesIO(), 302, 'Found', Message(), 'http://example.com/landing')
    with pytest.raises(HTTPError, match='outside the authorized scope'):
        handler.redirect_request(request, BytesIO(), 302, 'Found', Message(), 'https://example.com:8443/landing')

    same_host_redirect = handler.redirect_request(request, BytesIO(), 302, 'Found', Message(), 'https://example.com/next')
    assert same_host_redirect.full_url == 'https://example.com/next'


def test_normalized_denylisted_endpoint_is_excluded_from_prioritization():
    denylist_config = {'denylist': ['https://example.com/blocked']}
    assert safety.is_denylisted('HTTPS://EXAMPLE.COM:443/blocked', denylist_config)

    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'HTTPS://EXAMPLE.COM:443/blocked', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'Referrer-Policy', 'Validation status': 'Potential Finding'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {
        'safe_mode': True,
        'denylist': ['https://example.com/blocked'],
    }, logger=None)

    assert [item['endpoint'] for item in risk_data['prioritized_endpoints']] == ['https://example.com/']


@pytest.mark.parametrize('safe_mode', [True, False])
def test_scanner_requests_respect_shared_rate_limit(monkeypatch, tmp_path, safe_mode):
    calls = []

    class FakeResponse:
        headers = {'X-Frame-Options': 'DENY'}

        @staticmethod
        def geturl():
            return 'https://example.com'

    class FakeOpener:
        @staticmethod
        def open(url, timeout):
            calls.append(url)
            return FakeResponse()

    monkeypatch.setattr(safety, '_RATE_TRACKER', {})
    monkeypatch.setattr(safety, 'build_opener', lambda *handlers: FakeOpener())
    monkeypatch.setattr(scanner, 'RESULTS_DIR', tmp_path)
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
        'request_rate_limit': 1,
        'rate_window_seconds': 60,
    }

    first = scanner.run_scan('https://example.com', config, logger=None)
    second = scanner.run_scan('https://example.com', config, logger=None)

    assert first['scan_status'] == 'completed'
    assert second['scan_status'] == 'failed'
    assert len(calls) == 1


def test_scanner_reuses_discovery_headers_without_an_extra_request(monkeypatch):
    def unexpected_request(*args, **kwargs):
        raise AssertionError('cached discovery headers should not trigger another request')

    monkeypatch.setattr(scanner, 'open_scoped_url', unexpected_request)
    result = scanner.run_scan([{
        'url': 'https://example.com/',
        'reachable': True,
        'headers': {'X-Frame-Options': 'DENY'},
    }], {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': True,
    }, logger=None)

    assert result['scan_status'] == 'completed'
    assert result['endpoints'][0]['headers']['X-Frame-Options'] == 'PRESENT'


@pytest.mark.parametrize(
    ('addresses', 'message'),
    [
        (['93.184.216.34', '10.0.0.4'], 'non-global'),
        (['2606:4700:4700::1111', 'fe80::1'], 'non-global'),
        (['224.0.0.1'], 'non-global'),
        (['240.0.0.1'], 'non-global'),
        (['192.0.0.9'], 'non-global'),
        (['192.31.196.1'], 'non-global'),
        (['2002::1'], 'non-global'),
        (['64:ff9b::808:808'], 'non-global'),
        (['64:ff9b:1::1'], 'non-global'),
        (['2001:db8::1'], 'non-global'),
        (['2620:4f:8000::1'], 'non-global'),
        (['3fff::1'], 'non-global'),
        (['::ffff:8.8.8.8'], 'non-global'),
    ],
)
def test_dns_validation_rejects_non_global_or_special_answers(
    monkeypatch, addresses, message
):
    target = 'https://example.com'
    config = {'authorized_targets': [target], 'denylist': []}
    monkeypatch.setattr(
        safety,
        '_resolve_addresses',
        lambda host, port: [safety.ipaddress.ip_address(address) for address in addresses],
    )

    with pytest.raises(ValueError, match=message):
        safety._validated_address_for_url(target, target, config)


@pytest.mark.parametrize('safe_mode', [True, False])
@pytest.mark.parametrize(
    ('target', 'addresses', 'expected'),
    [
        (
            'http://127.0.0.1:8765',
            ['127.0.0.1'],
            '127.0.0.1',
        ),
        (
            'http://localhost:8765',
            ['127.0.0.1', '::1'],
            '127.0.0.1',
        ),
    ],
)
def test_explicitly_allowlisted_loopback_scope_is_preserved(
    monkeypatch, safe_mode, target, addresses, expected
):
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': safe_mode,
    }
    monkeypatch.setattr(
        safety,
        '_resolve_addresses',
        lambda host, port: [safety.ipaddress.ip_address(address) for address in addresses],
    )

    assert safety._validated_address_for_url(target, target, config) == expected


def test_dns_validation_checks_every_answer_before_selecting_address(monkeypatch):
    target = 'https://example.com'
    config = {'authorized_targets': [target], 'denylist': []}
    lookups = []

    def fake_resolve(host, port):
        lookups.append((host, port))
        return [
            safety.ipaddress.ip_address('93.184.216.34'),
            safety.ipaddress.ip_address('2606:4700:4700::1111'),
        ]

    monkeypatch.setattr(safety, '_resolve_addresses', fake_resolve)

    assert safety._validated_address_for_url(target, target, config) == '93.184.216.34'
    assert lookups == [('example.com', 443)]


def test_pinned_http_connection_connects_to_numeric_address_without_resolving(
    monkeypatch,
):
    connected = []

    class FakeSocket:
        def settimeout(self, timeout):
            pass

        def connect(self, address):
            connected.append(address)

        def close(self):
            pass

    monkeypatch.setattr(safety.socket, 'socket', lambda *args: FakeSocket())
    monkeypatch.setattr(
        safety.socket,
        'getaddrinfo',
        lambda *args, **kwargs: pytest.fail('Pinned connection performed DNS resolution'),
    )
    connection = safety._PinnedHTTPConnection(
        'example.com', '93.184.216.34', timeout=5
    )

    connection.connect()

    assert connected == [('93.184.216.34', 80)]


def test_pinned_https_connection_keeps_original_hostname_for_tls(monkeypatch):
    connected = []
    tls_names = []

    class FakeSocket:
        def settimeout(self, timeout):
            pass

        def connect(self, address):
            connected.append(address)

        def close(self):
            pass

    class FakeContext:
        check_hostname = True

        def wrap_socket(self, sock, server_hostname):
            tls_names.append(server_hostname)
            return sock

    monkeypatch.setattr(safety.socket, 'socket', lambda *args: FakeSocket())
    connection = safety._PinnedHTTPSConnection(
        'example.com',
        '93.184.216.34',
        timeout=5,
        context=FakeContext(),
    )

    connection.connect()

    assert connected == [('93.184.216.34', 443)]
    assert tls_names == ['example.com']


def test_same_hostname_redirect_resolves_and_pins_each_request(monkeypatch):
    target = 'http://example.com'
    config = {'authorized_targets': [target], 'denylist': []}
    resolutions = iter([
        [safety.ipaddress.ip_address('93.184.216.34')],
        [safety.ipaddress.ip_address('10.0.0.4')],
    ])
    connected = []

    class FakeSocket:
        def settimeout(self, timeout):
            pass

        def connect(self, address):
            connected.append(address)

        def close(self):
            pass

    monkeypatch.setattr(
        safety,
        '_resolve_addresses',
        lambda host, port: next(resolutions),
    )
    monkeypatch.setattr(safety.socket, 'socket', lambda *args: FakeSocket())
    handler = safety._PinnedHTTPHandler(target, config)

    def fake_do_open(factory, request):
        connection = factory(request.host, timeout=5)
        connection.connect()
        return connection

    monkeypatch.setattr(handler, 'do_open', fake_do_open)

    handler.http_open(Request(target))
    redirect_handler = ScopedRedirectHandler(target, config)
    redirected_request = redirect_handler.redirect_request(
        Request(target), BytesIO(), 302, 'Found', Message(), 'http://example.com/next'
    )

    with pytest.raises(ValueError, match='non-global'):
        handler.http_open(redirected_request)

    assert connected == [('93.184.216.34', 80)]


def test_scoped_opener_disables_environment_proxies(monkeypatch):
    target = 'http://example.com'
    config = {'authorized_targets': [target], 'denylist': []}
    captured_handlers = []
    build_opener = safety.build_opener

    class FakeResponse:
        def geturl(self):
            return target

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            return False

    class FakeOpener:
        def open(self, url, timeout):
            return FakeResponse()

    def fake_build_opener(*handlers):
        captured_handlers.extend(handlers)
        build_opener(*handlers)
        return FakeOpener()

    monkeypatch.setattr(
        safety,
        'build_opener',
        fake_build_opener,
    )

    with safety.open_scoped_url(target, target, config) as response:
        assert response.geturl() == target

    proxy_handler = next(
        handler for handler in captured_handlers
        if isinstance(handler, safety.ProxyHandler)
    )
    assert proxy_handler.proxies == {}


def test_endpoint_and_aggregate_risk_summaries_are_consistent():
    validation_data = {
        'target': 'https://example.com',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': f'Header-{index}', 'Validation status': 'Potential Finding'}
            for index in range(3)
        ] + [
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Referrer-Policy', 'Validation status': 'No issue found'},
        ],
    }

    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    by_endpoint = {item['endpoint']: item['risk_level'] for item in risk_data['endpoint_risk_summary']}

    assert by_endpoint['https://example.com/'] == 'medium'
    assert by_endpoint['https://example.com/about'] == 'low'
    assert risk_data['summary']['high_count'] == 0
    assert risk_data['summary']['medium_count'] == 3
    assert risk_data['summary']['low_count'] == 1
    assert risk_data['risk_levels']['high'] == []


def test_correlation_preserves_unvalidated_endpoints_without_creating_risk():
    successful_endpoint = 'https://example.com/about'
    failed_endpoint = 'https://example.com/unreachable'
    finding = {
        'Endpoint': successful_endpoint,
        'Finding name': 'Strict-Transport-Security',
        'Validation status': 'No issue found',
    }
    unvalidated_endpoint = {
        'endpoint': failed_endpoint,
        'scan_status': 'failed',
        'validation_status': 'not_assessed',
    }
    validation_data = {
        'target': 'https://example.com/',
        'findings': [finding],
        'unvalidated_endpoints': [unvalidated_endpoint],
    }
    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)

    correlation_data = correlation.correlate_findings(
        {'target': 'https://example.com/'}, validation_data, risk_data, logger=None
    )

    assert correlation_data['related_findings'] == [finding]
    assert correlation_data['unvalidated_endpoints'] == [unvalidated_endpoint]
    assert correlation_data['risk_summary'] == risk_data['summary']
    assert [item['endpoint'] for item in risk_data['endpoint_risk_summary']] == [successful_endpoint]


def test_correlation_defaults_missing_unvalidated_endpoints_for_legacy_data():
    validation_data = {
        'target': 'https://example.com/',
        'findings': [],
    }

    correlation_data = correlation.correlate_findings(
        {'target': 'https://example.com/'}, validation_data, {}, logger=None
    )

    assert correlation_data['unvalidated_endpoints'] == []


def test_evidence_links_multi_endpoint_findings_to_matching_scan_headers():
    scan_data = {
        'target': 'https://example.com/',
        'endpoints': [
            {
                'target': 'https://example.com/',
                'headers': {'Content-Security-Policy': 'NOT FOUND', 'X-Frame-Options': 'PRESENT'},
                'scan_status': 'completed',
            },
            {
                'target': 'https://example.com/about',
                'headers': {'Content-Security-Policy': 'WEAK VALUE', 'X-Frame-Options': 'NOT FOUND'},
                'scan_status': 'completed',
            },
        ],
    }
    validation_data = {
        'target': 'https://example.com/',
        'findings': [
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'X-Frame-Options', 'Validation status': 'No issue found'},
        ],
    }

    evidence_data = evidence.collect_evidence({}, scan_data, validation_data, logger=None)

    assert evidence_data['target'] == scan_data['target']
    assert evidence_data['sources'] == {'discovery': {}, 'scan': scan_data, 'validation': validation_data}
    assert evidence_data['evidence_status'] == 'collected'
    assert evidence_data['finding_evidence'] == [
        {
            'endpoint': 'https://example.com/about',
            'finding_name': 'Content-Security-Policy',
            'validation_status': 'Potential Finding',
            'observed_status': 'WEAK VALUE',
            'scan_status': 'completed',
            'source_identifier': 'scan.endpoints[].headers',
            'validation_source_pointer': '/sources/validation/findings/0',
            'scan_source_pointer': '/sources/scan/endpoints/1/headers/Content-Security-Policy',
        },
        {
            'endpoint': 'https://example.com/',
            'finding_name': 'X-Frame-Options',
            'validation_status': 'No issue found',
            'observed_status': 'PRESENT',
            'scan_status': 'completed',
            'source_identifier': 'scan.endpoints[].headers',
            'validation_source_pointer': '/sources/validation/findings/1',
            'scan_source_pointer': '/sources/scan/endpoints/0/headers/X-Frame-Options',
        },
    ]


def test_evidence_does_not_link_failed_scan_placeholder_headers(monkeypatch, tmp_path):
    monkeypatch.setattr(evidence, 'RESULTS_DIR', tmp_path)
    completed_endpoint = 'https://example.com/'
    failed_endpoint = 'https://example.com/unreachable'
    scan_data = {
        'target': completed_endpoint,
        'endpoints': [
            {
                'target': completed_endpoint,
                'headers': {'X-Frame-Options': 'PRESENT'},
                'scan_status': 'completed',
            },
            {
                'target': failed_endpoint,
                'headers': {'Content-Security-Policy': 'NOT FOUND'},
                'scan_status': 'failed',
            },
        ],
    }
    validation_data = {
        'target': completed_endpoint,
        'findings': [
            {
                'Endpoint': completed_endpoint,
                'Finding name': 'X-Frame-Options',
                'Validation status': 'No issue found',
            },
            {
                'Endpoint': failed_endpoint,
                'Finding name': 'Content-Security-Policy',
                'Validation status': 'Potential Finding',
            },
        ],
    }

    evidence_data = evidence.collect_evidence({}, scan_data, validation_data, logger=None)
    completed_record, failed_record = evidence_data['finding_evidence']

    assert completed_record['observed_status'] == 'PRESENT'
    assert completed_record['scan_status'] == 'completed'
    assert _resolve_json_pointer(evidence_data, completed_record['scan_source_pointer']) == 'PRESENT'
    assert failed_record['observed_status'] is None
    assert failed_record['scan_source_pointer'] is None
    assert failed_record['scan_status'] == 'failed'
    assert failed_record['validation_source_pointer'] == '/sources/validation/findings/1'
    assert _resolve_json_pointer(evidence_data, failed_record['validation_source_pointer']) == validation_data['findings'][1]


def test_evidence_supports_single_target_scan_and_missing_observations():
    scan_data = {
        'target': 'https://example.com/',
        'headers': {'Content-Security-Policy': 'NOT FOUND'},
        'scan_status': 'completed',
    }
    validation_data = {
        'target': 'https://example.com/',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/about', 'Finding name': 'Referrer-Policy', 'Validation status': 'Potential Finding'},
        ],
    }

    evidence_data = evidence.collect_evidence({}, scan_data, validation_data, logger=None)
    finding_evidence = evidence_data['finding_evidence']

    assert finding_evidence[0]['observed_status'] == 'NOT FOUND'
    assert finding_evidence[0]['scan_status'] == 'completed'
    assert finding_evidence[0]['source_identifier'] == 'scan.headers'
    assert finding_evidence[1]['observed_status'] is None
    assert finding_evidence[1]['scan_status'] == 'completed'
    assert finding_evidence[2]['observed_status'] is None
    assert finding_evidence[2]['scan_status'] is None


def test_finding_evidence_pointers_resolve_multi_endpoint_sources():
    scan_data = {
        'target': 'https://example.com/',
        'endpoints': [
            {'target': 'https://example.com/', 'headers': {'X-Frame-Options': 'PRESENT'}, 'scan_status': 'completed'},
            {'target': 'https://example.com/about', 'headers': {'X-Test/Policy~': 'WEAK VALUE'}, 'scan_status': 'completed'},
        ],
    }
    validation_data = {
        'target': 'https://example.com/',
        'findings': [
            {'Endpoint': 'https://example.com/about', 'Finding name': 'X-Test/Policy~', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'X-Frame-Options', 'Validation status': 'No issue found'},
        ],
    }

    evidence_data = evidence.collect_evidence({}, scan_data, validation_data, logger=None)
    records = evidence_data['finding_evidence']

    assert records[0]['validation_source_pointer'] == '/sources/validation/findings/0'
    assert _resolve_json_pointer(evidence_data, records[0]['validation_source_pointer']) == validation_data['findings'][0]
    assert records[0]['scan_source_pointer'] == '/sources/scan/endpoints/1/headers/X-Test~1Policy~0'
    assert _resolve_json_pointer(evidence_data, records[0]['scan_source_pointer']) == 'WEAK VALUE'
    assert records[1]['validation_source_pointer'] == '/sources/validation/findings/1'
    assert _resolve_json_pointer(evidence_data, records[1]['validation_source_pointer']) == validation_data['findings'][1]
    assert _resolve_json_pointer(evidence_data, records[1]['scan_source_pointer']) == 'PRESENT'


def test_finding_evidence_pointers_support_legacy_scan_and_missing_observation():
    scan_data = {
        'target': 'https://example.com/',
        'headers': {'Content-Security-Policy': 'NOT FOUND'},
        'scan_status': 'completed',
    }
    validation_data = {
        'target': 'https://example.com/',
        'findings': [
            {'Endpoint': 'https://example.com/', 'Finding name': 'Content-Security-Policy', 'Validation status': 'Potential Finding'},
            {'Endpoint': 'https://example.com/', 'Finding name': 'X-Frame-Options', 'Validation status': 'Potential Finding'},
        ],
    }

    evidence_data = evidence.collect_evidence({}, scan_data, validation_data, logger=None)
    records = evidence_data['finding_evidence']

    assert records[0]['validation_source_pointer'] == '/sources/validation/findings/0'
    assert _resolve_json_pointer(evidence_data, records[0]['validation_source_pointer']) == validation_data['findings'][0]
    assert records[0]['scan_source_pointer'] == '/sources/scan/headers/Content-Security-Policy'
    assert _resolve_json_pointer(evidence_data, records[0]['scan_source_pointer']) == 'NOT FOUND'
    assert records[1]['validation_source_pointer'] == '/sources/validation/findings/1'
    assert _resolve_json_pointer(evidence_data, records[1]['validation_source_pointer']) == validation_data['findings'][1]
    assert records[1]['observed_status'] is None
    assert records[1]['scan_source_pointer'] is None


@pytest.mark.parametrize('safe_mode', [True, False])
def test_standalone_scanner_rejects_unauthorized_target_before_request(
    monkeypatch, tmp_path, capsys, safe_mode
):
    target = 'https://example.org'
    calls = []
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
        'request_rate_limit': 1,
        'rate_window_seconds': 60,
    }

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(app_run, 'load_config', lambda: config)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(safety, 'open_scoped_url', lambda *args, **kwargs: calls.append(args))

    runpy.run_path(str(PROJECT_ROOT / 'scanner.py'), run_name='__main__')

    assert calls == []
    assert 'Target not authorized' in capsys.readouterr().out


def test_cli_rejects_unauthorized_target_when_safe_mode_disabled(monkeypatch, capsys):
    target = 'https://example.org'
    audit_records = []
    logger = SimpleNamespace(
        error=lambda *args: None,
        info=lambda *args: None,
        audit_logger=SimpleNamespace(
            error=lambda *args: audit_records.append(args),
            info=lambda *args: None,
        ),
    )
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': False,
    }

    monkeypatch.setattr(app_run, 'load_config', lambda: config)
    monkeypatch.setattr(app_run, 'setup_logger', lambda received_config: logger)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(
        discovery, 'run_discovery',
        lambda *args, **kwargs: pytest.fail('Unauthorized CLI target reached discovery'),
    )

    assert app_run.main() == 1
    assert 'Target blocked' in capsys.readouterr().out
    assert audit_records


@pytest.mark.parametrize('safe_mode', [True, False])
def test_legacy_discovery_rejects_unauthorized_target_before_request(
    monkeypatch, tmp_path, capsys, safe_mode
):
    target = 'https://example.org'
    audit_records = []
    logger = SimpleNamespace(
        error=lambda *args: None,
        info=lambda *args: None,
        audit_logger=SimpleNamespace(
            error=lambda *args: audit_records.append(args),
            info=lambda *args: None,
        ),
    )
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
    }

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(legacy_discovery, 'load_config', lambda: config)
    monkeypatch.setattr(legacy_discovery, 'setup_logger', lambda received_config: logger)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(
        legacy_discovery, 'open_scoped_url',
        lambda *args, **kwargs: pytest.fail('Unauthorized target reached the request opener'),
    )

    assert legacy_discovery.main() == 1
    assert 'Target blocked' in capsys.readouterr().out
    assert audit_records
    assert not (tmp_path / 'discovery_result.txt').exists()


def test_legacy_discovery_uses_scoped_opener_for_authorized_target(monkeypatch, tmp_path):
    target = 'https://example.com'
    calls = []
    audit_records = []
    logger = SimpleNamespace(
        error=lambda *args: None,
        info=lambda *args: None,
        audit_logger=SimpleNamespace(
            error=lambda *args: audit_records.append(args),
            info=lambda *args: audit_records.append(args),
        ),
    )
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': False,
        'timeout_seconds': 7,
    }

    class FakeResponse:
        status = 200
        headers = {'Server': 'test-server', 'Content-Type': 'text/html'}

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            return False

    def fake_open_scoped_url(url, scope_target, received_config, timeout):
        calls.append((url, scope_target, received_config, timeout))
        return FakeResponse()

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(legacy_discovery, 'load_config', lambda: config)
    monkeypatch.setattr(legacy_discovery, 'setup_logger', lambda received_config: logger)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(legacy_discovery, 'open_scoped_url', fake_open_scoped_url)

    assert legacy_discovery.main() == 0
    assert calls == [(target, target, config, 7)]
    report_text = (tmp_path / 'discovery_result.txt').read_text(encoding='utf-8')
    assert 'Target: https://example.com' in report_text
    assert 'Status Code: 200' in report_text
    assert audit_records


@pytest.mark.parametrize('safe_mode', [True, False])
def test_modular_discovery_and_scan_reject_unallowlisted_scope(
    monkeypatch, tmp_path, safe_mode
):
    target = 'https://example.org'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
        'request_rate_limit': 0,
    }
    opened = []

    for module in (discovery, scanner):
        monkeypatch.setattr(module, 'RESULTS_DIR', tmp_path / module.__name__)
    monkeypatch.setattr(
        safety, 'build_opener',
        lambda *args, **kwargs: opened.append((args, kwargs)),
    )

    discovery_result = discovery.run_discovery(target, config, logger=None)
    scan_result = scanner.run_scan(target, config, logger=None)

    assert discovery_result['reachable'] is False
    assert 'Target not authorized' in discovery_result['error']
    assert scan_result['scan_status'] == 'failed'
    assert 'Target is not explicitly authorized' in scan_result['error']
    assert opened == []


@pytest.mark.parametrize('safe_mode', [True, False])
def test_denylisted_discovery_root_is_rejected_before_candidates_or_opener(
    monkeypatch, tmp_path, safe_mode
):
    target = 'https://example.com/blocked'
    config = {
        'authorized_targets': [target],
        'denylist': ['https://example.com/blocked'],
        'safe_mode': safe_mode,
        'request_rate_limit': 0,
    }
    candidates = []
    opened = []
    monkeypatch.setattr(discovery, 'RESULTS_DIR', tmp_path)
    monkeypatch.setattr(
        discovery,
        'build_same_host_candidates',
        lambda *args, **kwargs: candidates.append(args),
    )
    monkeypatch.setattr(
        safety,
        'build_opener',
        lambda *args, **kwargs: opened.append((args, kwargs)),
    )

    with pytest.raises(ValueError, match='Target is denylisted'):
        safety.validate_discovery_scope(target, config)

    result = discovery.run_discovery(target, config, logger=None)

    assert result['reachable'] is False
    assert 'Target is denylisted' in result['error']
    assert candidates == []
    assert opened == []


@pytest.mark.parametrize('safe_mode', [True, False])
@pytest.mark.parametrize('module', [discovery, scanner])
def test_modular_paths_reject_allowlisted_url_credentials_before_processing(
    monkeypatch, tmp_path, safe_mode, module
):
    target = 'https://alice:secret@example.com'
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': safe_mode,
        'request_rate_limit': 0,
    }
    log_records = []
    logger = SimpleNamespace(
        info=lambda *args: log_records.append(args),
        error=lambda *args: log_records.append(args),
    )
    opened = []
    output_directory = tmp_path / module.__name__
    monkeypatch.setattr(module, 'RESULTS_DIR', output_directory)
    monkeypatch.setattr(
        safety,
        'build_opener',
        lambda *args, **kwargs: opened.append((args, kwargs)),
    )

    with pytest.raises(ValueError, match='username or password') as exc_info:
        if module is discovery:
            discovery.run_discovery(target, config, logger)
        else:
            scanner.run_scan(target, config, logger)

    assert 'alice' not in str(exc_info.value)
    assert 'secret' not in str(exc_info.value)
    assert log_records == []
    assert opened == []
    assert not output_directory.exists()


@pytest.mark.parametrize('safe_mode', [True, False])
def test_scoped_request_rejects_unallowlisted_target_before_opener(
    monkeypatch, safe_mode
):
    target = 'https://example.org'
    config = {
        'authorized_targets': ['https://example.com'],
        'denylist': [],
        'safe_mode': safe_mode,
        'request_rate_limit': 0,
    }
    opened = []
    monkeypatch.setattr(
        safety, 'build_opener',
        lambda *args, **kwargs: opened.append((args, kwargs)),
    )

    with pytest.raises(ValueError, match='not explicitly authorized'):
        safety.open_scoped_url(target, target, config)

    assert opened == []


@pytest.mark.parametrize('safe_mode', [True, False])
def test_cli_and_legacy_entry_points_do_not_log_allowlisted_credentials(
    monkeypatch, tmp_path, capsys, safe_mode
):
    target = 'https://alice:secret@example.com'
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': safe_mode,
    }
    log_records = []
    logger = SimpleNamespace(
        error=lambda *args: log_records.append(args),
        info=lambda *args: log_records.append(args),
        audit_logger=SimpleNamespace(
            error=lambda *args: log_records.append(args),
            info=lambda *args: log_records.append(args),
        ),
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(app_run, 'load_config', lambda: config)
    monkeypatch.setattr(app_run, 'setup_logger', lambda received_config: logger)
    monkeypatch.setattr(legacy_discovery, 'load_config', lambda: config)
    monkeypatch.setattr(legacy_discovery, 'setup_logger', lambda received_config: logger)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(
        discovery,
        'run_discovery',
        lambda *args, **kwargs: pytest.fail('Credentialed target reached discovery'),
    )
    monkeypatch.setattr(
        legacy_discovery,
        'open_scoped_url',
        lambda *args, **kwargs: pytest.fail('Credentialed target reached the opener'),
    )

    assert app_run.main() == 1
    assert legacy_discovery.main() == 1

    logged_text = repr(log_records) + capsys.readouterr().out
    assert 'alice' not in logged_text
    assert 'secret' not in logged_text
    assert not (tmp_path / 'discovery_result.txt').exists()


def test_dashboard_rejects_allowlisted_credentials_before_logger_or_opener(monkeypatch):
    target = 'https://alice:secret@example.com'
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': True,
    }
    monkeypatch.setattr(dashboard_app, 'load_config', lambda: config)
    monkeypatch.setattr(
        dashboard_app,
        'setup_logger',
        lambda received_config: pytest.fail('Credentialed target reached logging setup'),
    )
    monkeypatch.setattr(
        safety,
        'build_opener',
        lambda *args, **kwargs: pytest.fail('Credentialed target reached the opener'),
    )

    with pytest.raises(ValueError, match='username or password') as exc_info:
        dashboard_app.run_assessment(target)

    assert 'alice' not in str(exc_info.value)
    assert 'secret' not in str(exc_info.value)


@pytest.mark.parametrize('safe_mode', [True, False])
def test_standalone_scanner_does_not_print_allowlisted_credentials(
    monkeypatch, tmp_path, capsys, safe_mode
):
    target = 'https://alice:secret@example.com'
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': safe_mode,
    }
    opened = []
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(app_run, 'load_config', lambda: config)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(
        safety,
        'build_opener',
        lambda *args, **kwargs: opened.append((args, kwargs)),
    )

    runpy.run_path(str(PROJECT_ROOT / 'scanner.py'), run_name='__main__')

    output = capsys.readouterr().out
    assert 'alice' not in output
    assert 'secret' not in output
    assert opened == []
    assert not (tmp_path / 'scan_result.txt').exists()


def test_standalone_scanner_uses_scoped_opener_for_authorized_target(monkeypatch, tmp_path):
    target = 'https://example.com'
    calls = []
    config = {
        'authorized_targets': [target],
        'denylist': [],
        'safe_mode': True,
        'request_rate_limit': 1,
        'rate_window_seconds': 60,
    }

    class FakeResponse:
        headers = {
            'Content-Security-Policy': 'default-src \'self\'',
            'X-Frame-Options': 'DENY',
            'X-Content-Type-Options': 'nosniff',
        }

    def fake_open_scoped_url(url, scope_target, received_config, timeout):
        calls.append((url, scope_target, received_config, timeout))
        return FakeResponse()

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(app_run, 'load_config', lambda: config)
    monkeypatch.setattr('builtins.input', lambda *args: target)
    monkeypatch.setattr(safety, 'open_scoped_url', fake_open_scoped_url)

    runpy.run_path(str(PROJECT_ROOT / 'scanner.py'), run_name='__main__')

    assert calls == [(target, target, config, 5)]
    assert 'X-Frame-Options: PRESENT' in (tmp_path / 'scan_result.txt').read_text(encoding='utf-8')


def test_failed_multi_endpoint_scan_is_unvalidated_and_excluded_from_risk():
    failed_endpoint = 'https://example.com/unreachable'
    successful_endpoint = 'https://example.com/about'
    scan_data = {
        'target': 'https://example.com/',
        'endpoints': [
            {
                'target': failed_endpoint,
                'headers': {'Content-Security-Policy': 'NOT FOUND', 'X-Frame-Options': 'NOT FOUND'},
                'scan_status': 'failed',
            },
            {
                'target': successful_endpoint,
                'headers': {'Content-Security-Policy': 'NOT FOUND'},
                'scan_status': 'completed',
            },
        ],
    }

    validation_data = validation.run_validation(scan_data, logger=None)
    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)

    assert len(validation_data['findings']) == 1
    assert validation_data['findings'][0]['Finding name'] == 'Content-Security-Policy'
    assert validation_data['findings'][0]['Validation status'] == 'Potential Finding'
    assert validation_data['findings'][0]['Endpoint'] == successful_endpoint
    assert validation_data['unvalidated_endpoints'] == [{
        'endpoint': failed_endpoint,
        'scan_status': 'failed',
        'validation_status': 'not_assessed',
    }]
    assert risk_data['summary']['medium_count'] == 1
    assert all(item['Endpoint'] != failed_endpoint for item in risk_data['risk_levels']['medium'])


def test_failed_legacy_single_target_scan_is_unvalidated_and_excluded_from_risk():
    target = 'https://example.com/'
    scan_data = {
        'target': target,
        'headers': {'Content-Security-Policy': 'NOT FOUND', 'X-Frame-Options': 'NOT FOUND'},
        'scan_status': 'failed',
        'error': 'connection failed',
    }

    validation_data = validation.run_validation(scan_data, logger=None)
    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)

    assert validation_data['findings'] == []
    assert validation_data['unvalidated_endpoints'] == [{
        'endpoint': target,
        'scan_status': 'failed',
        'validation_status': 'not_assessed',
    }]
    assert risk_data['summary']['medium_count'] == 0
    assert risk_data['summary']['low_count'] == 0
    assert risk_data['endpoint_risk_summary'] == []


def test_failed_empty_endpoint_scan_is_unvalidated_and_preserved(monkeypatch, tmp_path):
    target = 'https://example.com/'
    scan_data = {
        'target': target,
        'endpoints': [],
        'scan_status': 'failed',
        'error': 'No endpoints to scan',
    }

    for module in (validation, risk, evidence, report):
        monkeypatch.setattr(module, 'RESULTS_DIR', tmp_path)

    validation_data = validation.run_validation(scan_data, logger=None)
    risk_data = risk.calculate_risk(validation_data, {'safe_mode': True}, logger=None)
    evidence_data = evidence.collect_evidence(
        {'target': target}, scan_data, validation_data, logger=None
    )
    report_data = report.generate_report(
        target,
        {'target': target},
        scan_data,
        validation_data,
        evidence_data,
        risk_data,
        {},
        logger=None,
    )

    assert validation_data['findings'] == []
    assert validation_data['unvalidated_endpoints'] == [{
        'endpoint': target,
        'scan_status': 'failed',
        'validation_status': 'not_assessed',
    }]
    assert risk_data['risk_levels']['medium'] == []
    assert risk_data['summary']['medium_count'] == 0
    assert risk_data['endpoint_risk_summary'] == []
    assert evidence_data['sources']['validation']['unvalidated_endpoints'] == validation_data['unvalidated_endpoints']
    assert report_data['validation']['unvalidated_endpoints'] == validation_data['unvalidated_endpoints']
    assert report_data['evidence']['sources']['validation']['unvalidated_endpoints'] == validation_data['unvalidated_endpoints']


def _mock_dashboard_assessment_setup(monkeypatch):
    config = {'safe_mode': True}
    audit = SimpleNamespace(info=lambda *args: None)
    logger = SimpleNamespace(audit_logger=audit)
    monkeypatch.setattr(dashboard_app, 'load_config', lambda: config)
    monkeypatch.setattr(dashboard_app, 'validate_target', lambda target, received_config: target)
    monkeypatch.setattr(dashboard_app, 'is_authorized_target', lambda target, received_config: True)
    monkeypatch.setattr(dashboard_app, 'is_denylisted', lambda target, received_config: False)
    monkeypatch.setattr(dashboard_app, 'setup_logger', lambda received_config: logger)


def test_dashboard_assessment_updates_progress_and_completes(monkeypatch):
    _mock_dashboard_assessment_setup(monkeypatch)
    observed = []

    def stage_stub(name, result):
        def run(*args, **kwargs):
            observed.append((name, dashboard_app._assessment_progress_snapshot()))
            return result
        return run

    stage_results = [
        ('Discovery', discovery, 'run_discovery', {'discovered_endpoints': []}),
        ('Header scan', scanner, 'run_scan', {'target': 'https://example.com/'}),
        ('Validation', validation, 'run_validation', {'target': 'https://example.com/'}),
        ('Evidence', evidence, 'collect_evidence', {'target': 'https://example.com/'}),
        ('Risk scoring', risk, 'calculate_risk', {'target': 'https://example.com/'}),
        ('Correlation', correlation, 'correlate_findings', {'target': 'https://example.com/'}),
        ('Report', report, 'generate_report', {'report': 'synthetic'}),
    ]
    for name, module, function_name, result in stage_results:
        monkeypatch.setattr(module, function_name, stage_stub(name, result))

    result = dashboard_app.run_assessment('https://example.com/', 'test-run-id')

    assert result == {'report': 'synthetic'}
    assert observed == [
        (name, {'run_id': 'test-run-id', 'stage': name, 'status': 'running'})
        for name, _, _, _ in stage_results
    ]
    assert dashboard_app._assessment_progress_snapshot() == {
        'run_id': 'test-run-id',
        'stage': 'Report',
        'status': 'completed',
    }


def test_dashboard_assessment_marks_failed_stage(monkeypatch):
    _mock_dashboard_assessment_setup(monkeypatch)
    monkeypatch.setattr(discovery, 'run_discovery', lambda *args: {'discovered_endpoints': []})

    def fail_scan(*args):
        raise RuntimeError('synthetic stage failure')

    monkeypatch.setattr(scanner, 'run_scan', fail_scan)

    with pytest.raises(RuntimeError, match='synthetic stage failure'):
        dashboard_app.run_assessment('https://example.com/', 'failed-run-id')

    assert dashboard_app._assessment_progress_snapshot() == {
        'run_id': 'failed-run-id',
        'stage': 'Header scan',
        'status': 'failed',
    }


def test_dashboard_state_exposes_safe_progress_snapshot(monkeypatch):
    monkeypatch.setattr(dashboard_app, 'load_config', lambda: {'authorized_targets': []})
    monkeypatch.setattr(dashboard_app, 'read_json', lambda name: None)
    monkeypatch.setattr(dashboard_app, 'ASSESSMENT_PROGRESS', {
        'run_id': 'test-run-id',
        'stage': 'Validation',
        'status': 'running',
    })
    response = {}
    handler = object.__new__(dashboard_app.Handler)
    handler.path = '/api/state'
    handler._local_only = lambda: True
    handler._json = lambda payload, status=200: response.update(payload=payload, status=status)

    handler.do_GET()

    assert response['status'] == 200
    assert response['payload']['progress'] == {
        'run_id': 'test-run-id',
        'stage': 'Validation',
        'status': 'running',
    }
    assert set(response['payload']['progress']) == {'run_id', 'stage', 'status'}


def test_dashboard_scan_lock_and_post_errors_are_preserved(monkeypatch):
    responses = []
    handler = object.__new__(dashboard_app.Handler)
    handler.path = '/api/scan'
    handler._local_only = lambda: True
    handler._json = lambda payload, status=200: responses.append((payload, status))

    assert dashboard_app.SCAN_LOCK.acquire(blocking=False)
    try:
        handler.do_POST()
        assert responses[-1][0]['error'] == 'An assessment is already running.'
        assert responses[-1][1] == 409
        assert dashboard_app.SCAN_LOCK.locked()
    finally:
        dashboard_app.SCAN_LOCK.release()

    monkeypatch.setattr(handler, '_body', lambda: {'authorized': True, 'target': 'https://example.com/'})
    monkeypatch.setattr(dashboard_app, 'normalize_target', lambda target: target)

    def fail_assessment(target, run_id):
        raise RuntimeError('synthetic assessment failure')

    monkeypatch.setattr(dashboard_app, 'run_assessment', fail_assessment)
    handler.do_POST()

    assert responses[-1][0]['error'] == 'Assessment could not be completed: synthetic assessment failure'
    assert responses[-1][1] == 500
    assert responses[-1][0]['progress']['status'] == 'failed'
    assert not dashboard_app.SCAN_LOCK.locked()


def test_dashboard_new_post_replaces_previous_terminal_progress(monkeypatch):
    _mock_dashboard_assessment_setup(monkeypatch)
    run_id = 'a' * 32
    monkeypatch.setattr(dashboard_app, 'ASSESSMENT_PROGRESS', {
        'run_id': 'previous-run',
        'stage': 'Report',
        'status': 'completed',
    })
    stage_snapshots = []

    def stage_stub(result):
        def run(*args, **kwargs):
            stage_snapshots.append(dashboard_app._assessment_progress_snapshot())
            return result
        return run

    for module, function_name, result in [
        (discovery, 'run_discovery', {'discovered_endpoints': []}),
        (scanner, 'run_scan', {'target': 'https://example.com/'}),
        (validation, 'run_validation', {'target': 'https://example.com/'}),
        (evidence, 'collect_evidence', {'target': 'https://example.com/'}),
        (risk, 'calculate_risk', {'target': 'https://example.com/'}),
        (correlation, 'correlate_findings', {'target': 'https://example.com/'}),
        (report, 'generate_report', {'report': 'synthetic'}),
    ]:
        monkeypatch.setattr(module, function_name, stage_stub(result))

    monkeypatch.setattr(dashboard_app, 'normalize_target', lambda target: target)
    post_response = {}
    post_handler = object.__new__(dashboard_app.Handler)
    post_handler.path = '/api/scan'
    post_handler._local_only = lambda: True
    post_handler._body = lambda: {
        'authorized': True,
        'target': 'https://example.com/',
        'run_id': run_id,
    }
    post_handler._json = lambda payload, status=200: post_response.update(payload=payload, status=status)

    post_handler.do_POST()

    assert post_response['status'] == 200
    assert post_response['payload']['progress'] == {
        'run_id': run_id,
        'stage': 'Report',
        'status': 'completed',
    }
    assert all(snapshot['run_id'] == run_id for snapshot in stage_snapshots)

    monkeypatch.setattr(dashboard_app, 'read_json', lambda name: None)
    state_response = {}
    state_handler = object.__new__(dashboard_app.Handler)
    state_handler.path = '/api/state'
    state_handler._local_only = lambda: True
    state_handler._json = lambda payload, status=200: state_response.update(payload=payload, status=status)

    state_handler.do_GET()

    assert state_response['payload']['progress'] == post_response['payload']['progress']


def test_dashboard_rejected_post_returns_failed_progress(monkeypatch):
    _mock_dashboard_assessment_setup(monkeypatch)
    run_id = 'b' * 32
    monkeypatch.setattr(dashboard_app, 'ASSESSMENT_PROGRESS', {
        'run_id': 'previous-run',
        'stage': 'Validation',
        'status': 'failed',
    })
    response = {}
    handler = object.__new__(dashboard_app.Handler)
    handler.path = '/api/scan'
    handler._local_only = lambda: True
    handler._body = lambda: {'authorized': False, 'run_id': run_id}
    handler._json = lambda payload, status=200: response.update(payload=payload, status=status)

    handler.do_POST()

    assert response['status'] == 400
    assert response['payload']['error'] == 'Confirm authorization in the dashboard before starting an assessment.'
    assert response['payload']['progress'] == {
        'run_id': run_id,
        'stage': 'Authorization',
        'status': 'failed',
    }


def _dashboard_script():
    return dashboard_app.PAGE.split('<script>', 1)[1].split('</script>', 1)[0]


def test_dashboard_renders_escaped_recommended_remediation():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "typeof f['Recommended remediation']==='string'" in render
    assert "f['Recommended remediation'].trim()" in render
    assert "${esc(remediation)}" in render
    assert "${remediation?`<p><strong>Recommended remediation:</strong>" in render


def test_dashboard_renders_validation_status_label():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "Validation status" in render
    assert "f['Validation status']" in render


def test_dashboard_risk_label_mentions_provisional_status():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "Risk level" in render
    assert "Provisional risk" in render


def test_dashboard_renders_unvalidated_endpoint_section():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "unvalidated_endpoints" in render
    assert "Not assessed" in render
    assert "$('#unvalidated')" in render


def test_dashboard_renders_prioritized_endpoints_section():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "summary?.prioritized_endpoints" in render
    assert "risk_level" in render
    assert "$('#prioritized')" in render


def test_dashboard_renders_evidence_available_label_when_backend_has_it():
    script = _dashboard_script()
    render = script.split('function render(r,targets,lastRun){', 1)[1].split(
        '\nconst progressStages', 1
    )[0]

    assert "Evidence available" in render
    assert "finding_evidence" in render


def test_dashboard_finding_label_uses_available_risk_or_neutral_fallback():
    script = _dashboard_script()

    assert "items.high||[]).map(x=>({...x,_level:'High'}))" in script
    assert "items.medium||[]).map(x=>({...x,_level:'Medium'}))" in script
    assert "items.low||[]).map(x=>({...x,_level:'Low'}))" in script
    assert "['Critical','High','Medium','Low'].includes(f._level)?f._level.toUpperCase():'Potential Finding'" in script


def test_dashboard_progress_script_updates_only_valid_state():
    script = _dashboard_script()

    assert "progressStatuses.has(data.progress.status)" in script
    assert "progressStages.has(data.progress.stage)" in script
    assert "new Set(['Authorization',...stages])" in script
    assert "typeof data.progress.run_id==='string'" in script
    assert "data.progress.run_id!==runId" in script
    assert "if(!isValidProgressState(data))throw new Error('Malformed progress response')" in script
    assert "lastProgress={run_id:runId,stage:data.progress.stage,status:data.progress.status}" in script
    assert "Assessment ${progress.status} · ${progress.stage}" in script


def test_dashboard_progress_script_bounds_mismatched_run_ids():
    script = _dashboard_script()

    assert 'const maxProgressMismatchMs=10000' in script
    assert 'progressPollStartedAt=performance.now()' in script
    assert 'const elapsed=performance.now()-progressPollStartedAt' in script
    assert 'if(elapsed>=maxProgressMismatchMs){stopProgressPolling(runId)' in script
    assert "Assessment progress could not be matched to this scan." in script
    assert 'Math.min(500,maxProgressMismatchMs-elapsed)' in script


def test_dashboard_progress_script_deadline_aborts_hung_request():
    script = _dashboard_script()

    assert 'let progressDeadlineTimer=null' in script
    assert 'progressDeadlineTimer=window.setTimeout(()=>{if(!progressPolling||activeRunId!==runId)return;stopProgressPolling(runId)' in script
    assert '},maxProgressMismatchMs)' in script
    assert 'if(!progressPolling||activeRunId!==runId)return' in script


def test_dashboard_progress_script_bounds_http_json_and_shape_errors():
    script = _dashboard_script()

    assert "if(!r.ok)throw new Error('Dashboard state unavailable')" in script
    assert "if(!response.ok)throw new Error('Progress unavailable')" in script
    assert "await response.json()" in script
    assert 'maxProgressPollFailures=3' in script
    assert 'progressPollFailures>=maxProgressPollFailures' in script
    assert 'Math.min(2**progressPollFailures,4)' in script


def test_dashboard_progress_script_cleans_up_pending_poll():
    script = _dashboard_script()
    cleanup = script.split('function stopProgressPolling(runId)', 1)[1].split('\n', 1)[0]

    assert 'window.clearTimeout(progressPollTimer)' in cleanup
    assert 'window.clearTimeout(progressDeadlineTimer)' in cleanup
    assert 'controller.abort()' in cleanup
    assert "signal:controller.signal" in script
    assert "finally{stopProgressPolling(runId);" in script
    assert 'if(progressPolling&&activeRunId===runId)progressPollTimer=window.setTimeout' in script


def test_dashboard_progress_script_preserves_final_status():
    script = _dashboard_script()

    assert 'scanSucceeded=true' in script
    assert "if(scanSucceeded){lastProgress=lastProgress?.status==='completed'?lastProgress:{run_id:runId,stage:'Report',status:'completed'};showProgress(lastProgress)}" in script
    assert "if(lastProgress?.status==='failed'){showProgress(lastProgress);status.textContent+=` · ${e.message}`}" in script
    assert 'Assessment complete. The report and evidence are saved locally in results/.' not in script
    assert "run_id:runId" in script
