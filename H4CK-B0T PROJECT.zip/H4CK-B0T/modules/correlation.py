import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def correlate_findings(discovery_data, validation_data, risk_data, config=None, logger=None):
    """Associate discovered target details with validation findings and risk summary."""
    target = (discovery_data or {}).get("target") or (validation_data or {}).get("target") or "Unknown target"
    findings = (validation_data or {}).get("findings", [])
    unvalidated_endpoints = (validation_data or {}).get("unvalidated_endpoints", [])
    summary = (risk_data or {}).get("summary", {})

    payload = {
        "target": target,
        "related_findings": findings,
        "unvalidated_endpoints": unvalidated_endpoints,
        "risk_summary": summary,
        "correlation_status": "completed",
    }
    _write_json("correlation_result.json", payload)
    _log(logger, f"Correlation completed for {target}")
    return payload
