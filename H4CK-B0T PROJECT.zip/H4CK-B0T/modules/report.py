import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def generate_report(target, discovery_data, scan_data, validation_data, evidence_data, risk_data, correlation_data, config=None, logger=None):
    """Generate a structured report object for the pipeline output."""
    endpoint_count = 1
    if isinstance((scan_data or {}).get("endpoints"), list):
        endpoint_count = len(scan_data["endpoints"])
    elif isinstance((discovery_data or {}).get("discovered_endpoints"), list):
        endpoint_count = len(discovery_data["discovered_endpoints"])

    payload = {
        "target": target,
        "discovery": discovery_data,
        "scan": scan_data,
        "validation": validation_data,
        "evidence": evidence_data,
        "risk": risk_data,
        "correlation": correlation_data,
        "report_status": "completed",
        "summary": {
            "endpoint_count": endpoint_count,
            "target": target,
            "endpoint_risk_summary": (risk_data or {}).get("endpoint_risk_summary", []),
            "prioritized_endpoints": (risk_data or {}).get("prioritized_endpoints", []),
        },
    }
    _write_json("report.json", payload)
    _log(logger, f"Report generated for {target}")
    return payload
