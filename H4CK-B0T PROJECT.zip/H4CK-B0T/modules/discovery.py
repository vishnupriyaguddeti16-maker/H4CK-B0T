import json
from pathlib import Path
from urllib.parse import urlparse

from utils.safety import (
    build_same_host_candidates,
    open_scoped_url,
    reject_url_credentials,
    validate_discovery_scope,
)

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


```python
def _classify_endpoint(url, target, reachable, content_type, headers=None):
    classifications = []
    headers = headers or {}

    if url == target:
        classifications.append("Authorized root target")

    if not reachable:
        classifications.append("Unreachable endpoint")
        return classifications

    classifications.append("Reachable HTTP endpoint")

    # Record passive header observations only.
    # These do not prove a vulnerability or confirm a technology.
    server_value = next(
        (value for key, value in headers.items() if key.lower() == "server"),
        None,
    )
    if isinstance(server_value, str) and server_value.strip():
        classifications.append("Unverified Server header observation")

    powered_by_value = next(
        (value for key, value in headers.items() if key.lower() == "x-powered-by"),
        None,
    )
    if isinstance(powered_by_value, str) and powered_by_value.strip():
        classifications.append("X-Powered-By header observation")

    if not isinstance(content_type, str) or not content_type.strip():
        return classifications

    media_type = content_type.split(";", 1)[0].strip().lower()

    if (
        media_type == "application/json"
        or media_type.endswith("+json")
        or media_type == "text/json"
    ):
        classifications.append("JSON content")
        path_segments = urlparse(url).path.lower().split("/")
        if "api" in path_segments:
            classifications.append("Possible API endpoint")
    elif (
        media_type == "text/html"
        or media_type == "application/xhtml+xml"
        or media_type.startswith("text/")
    ):
        classifications.append("Web content")
    else:
        classifications.append("Other HTTP content")

    return classifications
```


def run_discovery(target, config=None, logger=None):
    """Perform a safe discovery pass for an authorized target and a same-host candidate set."""
    reject_url_credentials(target)
    config = config or {}
    timeout = int(config.get("timeout_seconds", 5) or 5)

    try:
        validated_target = validate_discovery_scope(target, config)
        parsed = urlparse(validated_target)
        candidates = build_same_host_candidates(validated_target, config)

        discovered = []
        root_response = None
        for candidate in candidates:
            try:
                response = open_scoped_url(candidate, validated_target, config, timeout=timeout)
                headers = {}
                for key, value in response.headers.items():
                    headers[key] = value

                entry = {
                    "url": candidate,
                    "status_code": getattr(response, "status", "unknown"),
                    "final_url": response.geturl(),
                    "server": response.headers.get("Server"),
                    "content_type": response.headers.get("Content-Type"),
                    "headers": headers,
                    "reachable": True,
                    "error": None,
                }
                entry["classifications"] = _classify_endpoint(
                    entry["url"],
                    validated_target,
                    entry["reachable"],
                    entry["content_type"],
                )
                if root_response is None:
                    root_response = response
                discovered.append(entry)
            except Exception as exc:  # pragma: no cover - defensive fallback
                entry = {
                    "url": candidate,
                    "status_code": None,
                    "final_url": None,
                    "server": None,
                    "content_type": None,
                    "headers": {},
                    "reachable": False,
                    "error": str(exc),
                }
                entry["classifications"] = _classify_endpoint(
                    entry["url"],
                    validated_target,
                    entry["reachable"],
                    entry["content_type"],
                )
                if root_response is None:
                    root_response = None
                discovered.append(entry)

        response_headers = {}
        if root_response is not None:
            for key, value in root_response.headers.items():
                response_headers[key] = value

        data = {
            "target": validated_target,
            "canonical_url": validated_target,
            "scheme": parsed.scheme,
            "host": parsed.hostname,
            "domain": parsed.netloc,
            "port": parsed.port,
            "path": parsed.path or "/",
            "query": parsed.query,
            "fragment": parsed.fragment,
            "authorized_scope": {
                "allowlisted": True,
                "same_host_authorized": True,
                "safe_mode": bool(config.get("safe_mode", True)),
            },
            "discovered_endpoints": discovered,
            "endpoint_count": len(discovered),
            "reachable_endpoints": sum(1 for item in discovered if item.get("reachable")),
            "response": {
                "status_code": getattr(root_response, "status", "unknown") if root_response is not None else None,
                "final_url": root_response.geturl() if root_response is not None else None,
                "server": root_response.headers.get("Server") if root_response is not None else None,
                "content_type": root_response.headers.get("Content-Type") if root_response is not None else None,
                "headers": response_headers,
                "reachable": root_response is not None,
            },
            "reachable": root_response is not None,
            "error": None,
        }

        _write_json("discovery_result.json", data)
        _log(logger, f"Discovery succeeded for {validated_target}")
        return data
    except Exception as exc:  # pragma: no cover - defensive fallback
        parsed = urlparse(target)
        data = {
            "target": target,
            "canonical_url": target,
            "scheme": parsed.scheme,
            "host": parsed.hostname,
            "domain": parsed.netloc,
            "port": parsed.port,
            "path": parsed.path or "/",
            "query": parsed.query,
            "fragment": parsed.fragment,
            "authorized_scope": {
                "allowlisted": False,
                "same_host_authorized": False,
                "safe_mode": bool(config.get("safe_mode", True)),
            },
            "discovered_endpoints": [],
            "endpoint_count": 0,
            "reachable_endpoints": 0,
            "response": {
                "status_code": None,
                "final_url": None,
                "server": None,
                "content_type": None,
                "headers": {},
                "reachable": False,
            },
            "reachable": False,
            "error": str(exc),
        }
        _write_json("discovery_result.json", data)
        _log(logger, f"Discovery failed for {target}: {exc}", level="error")
        return data
