import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def _escape_json_pointer_token(token):
    return str(token).replace("~", "~0").replace("/", "~1")


def _build_finding_evidence(scan_data, validation_data):
    scan_data = scan_data or {}
    validation_data = validation_data or {}
    endpoint_scans = {}

    if isinstance(scan_data.get("endpoints"), list):
        source = "scan.endpoints[].headers"
        for endpoint_index, endpoint_scan in enumerate(scan_data["endpoints"]):
            if not isinstance(endpoint_scan, dict):
                continue
            endpoint = endpoint_scan.get("target") or endpoint_scan.get("url")
            if endpoint:
                endpoint_scans[endpoint] = (endpoint_scan, endpoint_index)
    else:
        source = "scan.headers"
        endpoint = scan_data.get("target")
        if endpoint:
            endpoint_scans[endpoint] = (scan_data, None)

    default_endpoint = validation_data.get("target") or scan_data.get("target")
    finding_evidence = []
    findings = validation_data.get("findings", [])
    if not isinstance(findings, (list, tuple)):
        return finding_evidence

    for finding_index, finding in enumerate(findings):
        if not isinstance(finding, dict):
            continue
        endpoint = finding.get("Endpoint") or default_endpoint
        finding_name = finding.get("Finding name")
        endpoint_scan, endpoint_index = endpoint_scans.get(endpoint, ({}, None))
        headers = endpoint_scan.get("headers", {})
        has_observation = (
            endpoint_scan.get("scan_status") != "failed"
            and isinstance(headers, dict)
            and finding_name in headers
        )
        observed_status = headers.get(finding_name) if has_observation else None
        if has_observation and endpoint_index is not None:
            scan_source_pointer = (
                f"/sources/scan/endpoints/{endpoint_index}/headers/"
                f"{_escape_json_pointer_token(finding_name)}"
            )
        elif has_observation:
            scan_source_pointer = f"/sources/scan/headers/{_escape_json_pointer_token(finding_name)}"
        else:
            scan_source_pointer = None

        finding_evidence.append({
            "endpoint": endpoint,
            "finding_name": finding_name,
            "validation_status": finding.get("Validation status"),
            "observed_status": observed_status,
            "scan_status": endpoint_scan.get("scan_status"),
            "source_identifier": source,
            "validation_source_pointer": f"/sources/validation/findings/{finding_index}",
            "scan_source_pointer": scan_source_pointer,
        })

    return finding_evidence


def collect_evidence(discovery_data, scan_data, validation_data, config=None, logger=None):
    """Collect the discovery, scan, and validation data in a structured evidence payload."""
    payload = {
        "target": (discovery_data or {}).get("target") or (scan_data or {}).get("target") or "Unknown target",
        "sources": {
            "discovery": discovery_data,
            "scan": scan_data,
            "validation": validation_data,
        },
        "finding_evidence": _build_finding_evidence(scan_data, validation_data),
        "evidence_status": "collected",
    }
    _write_json("evidence_result.json", payload)
    _log(logger, f"Evidence collected for {payload['target']}")
    return payload
