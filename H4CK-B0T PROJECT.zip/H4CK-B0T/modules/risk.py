import json
from pathlib import Path

from utils.safety import same_host_allowed

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"

# Risk is intentionally provisional: these findings are observations from the current
# validation results, not confirmed vulnerabilities. The rubric only uses fields already
# present in validation output and never infers business context or threat intelligence.
# Likelihood is based on the number of current potential findings on an endpoint and the
# observed security headers that are already present in the scan results. Impact is limited
# to the supported headers and their observed controls; missing headers are treated as
# provisional findings only.
HEADER_IMPACT = {
    "Strict-Transport-Security": 3,
    "Content-Security-Policy": 3,
    "Set-Cookie": 3,
    "Permissions-Policy": 2,
    "X-Frame-Options": 2,
    "Cross-Origin-Opener-Policy": 2,
    "Referrer-Policy": 2,
    "X-Content-Type-Options": 1,
}


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def _impact_score_for_finding(finding):
    header_name = (finding or {}).get("Finding name") or ""
    return HEADER_IMPACT.get(header_name, 0)


def _risk_level_for_endpoint(potential_findings, max_impact):
    # A missing security header or weak header value is still a provisional observation.
    # We do not upgrade it to a confirmed vulnerability without stronger evidence.
    if potential_findings == 0:
        return "low"
    if potential_findings >= 5 or (potential_findings >= 3 and max_impact >= 3):
        return "high"
    return "medium"


def calculate_risk(validation_data, config=None, logger=None):
    """Assign a provisional risk level from the existing validation findings only.

    The project does not have exploitability, business criticality, or attacker intelligence
    in its current assessment output. Risk therefore reflects only observed validation states,
    supported security headers, and the count of potential findings per endpoint. Missing
    assessment data is ignored rather than converted into a misleading score.
    """
    config = config or {}
    findings = (validation_data or {}).get("findings", [])
    if not isinstance(findings, list):
        findings = []
    target = (validation_data or {}).get("target", "Unknown target")
    endpoint_count = len((validation_data or {}).get("endpoints", [])) if isinstance((validation_data or {}).get("endpoints"), list) else 1
    medium = []
    low = []
    high = []

    endpoint_totals = {}
    for item in findings:
        if not isinstance(item, dict):
            continue
        endpoint = item.get("Endpoint") or target
        try:
            if not same_host_allowed(target, endpoint, config):
                continue
        except ValueError:
            continue

        stats = endpoint_totals.setdefault(endpoint, {
            "endpoint": endpoint,
            "potential_findings": 0,
            "no_issue_findings": 0,
            "total_findings": 0,
            "max_impact": 0,
        })

        if item.get("Validation status") == "Potential Finding":
            stats["potential_findings"] += 1
            stats["max_impact"] = max(stats["max_impact"], _impact_score_for_finding(item))
            medium.append(item)
        else:
            stats["no_issue_findings"] += 1
            low.append(item)
        stats["total_findings"] += 1

    endpoint_risk_summary = []
    for endpoint, stats in endpoint_totals.items():
        potential_count = stats["potential_findings"]
        max_impact = stats["max_impact"]
        risk_level = _risk_level_for_endpoint(potential_count, max_impact)
        if risk_level == "high":
            high.extend(item for item in findings if isinstance(item, dict) and item.get("Endpoint") == endpoint and item.get("Validation status") == "Potential Finding")
        endpoint_risk_summary.append({
            "endpoint": endpoint,
            "risk_level": risk_level,
            "potential_findings": potential_count,
            "no_issue_findings": stats["no_issue_findings"],
            "total_findings": stats["total_findings"],
        })

    endpoint_risk_summary.sort(key=lambda item: (
        {"high": 3, "medium": 2, "low": 1}[item["risk_level"]],
        item["potential_findings"],
        -item["no_issue_findings"],
        item["endpoint"],
    ), reverse=True)
    prioritized_endpoints = []
    for item in endpoint_risk_summary:
        prioritized_endpoints.append({
            "endpoint": item["endpoint"],
            "risk_level": item["risk_level"],
            "potential_findings": item["potential_findings"],
            "total_findings": item["total_findings"],
        })

    # Keep the legacy payload structure stable while using the new provisional risk rubric.
    payload = {
        "target": target,
        "risk_levels": {
            "high": high,
            "medium": [item for item in medium if item not in high],
            "low": low,
        },
        "summary": {
            "high_count": len(high),
            "medium_count": len(medium) - len(high),
            "low_count": len(low),
            "endpoint_count": endpoint_count,
        },
        "endpoint_risk_summary": endpoint_risk_summary,
        "prioritized_endpoints": prioritized_endpoints,
    }
    _write_json("risk_result.json", payload)
    _log(logger, f"Risk calculated for {payload['target']}")
    return payload
