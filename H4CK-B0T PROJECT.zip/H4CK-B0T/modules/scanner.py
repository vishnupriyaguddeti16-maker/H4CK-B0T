import json
from pathlib import Path

from utils.safety import (
    is_same_host_authorized,
    open_scoped_url,
    reject_url_credentials,
    same_host_allowed,
)

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def _evaluate_header_value(header_name, value):
    """Classify security headers as present, missing, or weak using simple deterministic checks."""
    if not value:
        return "NOT FOUND"

    normalized = value.strip()
    if not normalized:
        return "NOT FOUND"

    lower_value = normalized.lower()

    if header_name == "Strict-Transport-Security":
        if "max-age=0" in lower_value:
            return "WEAK VALUE"
        return "PRESENT"

    if header_name == "Referrer-Policy":
        if "unsafe-url" in lower_value:
            return "WEAK VALUE"
        return "PRESENT"

    if header_name == "Permissions-Policy":
        if "*" in normalized or "()" in normalized:
            return "WEAK VALUE"
        return "PRESENT"

    if header_name == "Cross-Origin-Opener-Policy":
        if "unsafe-none" in lower_value:
            return "WEAK VALUE"
        return "PRESENT"

    return "PRESENT"


def _evaluate_cookie_attributes(cookie_value):
    """Evaluate a Set-Cookie value for basic protection attributes."""
    if not cookie_value:
        return "NOT FOUND"

    normalized = cookie_value.strip()
    if not normalized:
        return "NOT FOUND"

    lower_cookie = normalized.lower()
    has_secure = "secure" in lower_cookie
    has_httponly = "httponly" in lower_cookie
    same_site = None
    if "samesite=" in lower_cookie:
        same_site = lower_cookie.split("samesite=")[-1].split(";")[0].strip()

    if not has_secure:
        return "WEAK VALUE"
    if not has_httponly:
        return "WEAK VALUE"
    if not same_site:
        return "WEAK VALUE"
    if same_site == "none" and not has_secure:
        return "WEAK VALUE"
    return "PRESENT"


def _get_set_cookie_values(headers):
    """Support both email.message.Message-style headers and dict-like test doubles."""
    if headers is None:
        return []
    if hasattr(headers, "get_all"):
        values = headers.get_all("Set-Cookie")
        if values:
            return values
    value = headers.get("Set-Cookie")
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _scan_single_endpoint(target, config=None, logger=None, scope_target=None):
    """Check a safe subset of HTTP security headers and cookie protections for one endpoint."""
    reject_url_credentials(target)
    config = config or {}
    timeout = int(config.get("timeout_seconds", 5) or 5)
    headers_to_check = [
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Strict-Transport-Security",
        "Referrer-Policy",
        "Permissions-Policy",
        "Cross-Origin-Opener-Policy",
    ]

    try:
        response = open_scoped_url(target, scope_target or target, config, timeout=timeout)
        payload = _scan_response_headers(target, response.headers)
        _log(logger, f"Scan completed for {target}")
        return payload
    except Exception as exc:  # pragma: no cover - defensive fallback
        payload = {
            "target": target,
            "headers": {header: "NOT FOUND" for header in headers_to_check + ["Set-Cookie"]},
            "scan_status": "failed",
            "error": str(exc),
        }
        _log(logger, f"Scan failed for {target}: {exc}", level="error")
        return payload


def _scan_response_headers(target, response_headers):
    headers_to_check = [
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Strict-Transport-Security",
        "Referrer-Policy",
        "Permissions-Policy",
        "Cross-Origin-Opener-Policy",
    ]
    checks = {
        header: _evaluate_header_value(header, response_headers.get(header))
        for header in headers_to_check
    }
    set_cookie_values = _get_set_cookie_values(response_headers)
    if set_cookie_values:
        cookie_results = [_evaluate_cookie_attributes(cookie) for cookie in set_cookie_values]
        checks["Set-Cookie"] = "PRESENT" if all(status == "PRESENT" for status in cookie_results) else "WEAK VALUE"
    else:
        checks["Set-Cookie"] = "NOT FOUND"

    return {
        "target": target,
        "headers": checks,
        "scan_status": "completed",
        "error": None,
    }


def run_scan(target, config=None, logger=None):
    """Check a safe subset of HTTP security headers and cookie protections for one or more same-host endpoints."""
    config = config or {}

    if isinstance(target, (list, tuple, set)):
        endpoints = list(target)
        scanned = []
        endpoint_values = [
            (endpoint.get("url") or endpoint.get("target")) if isinstance(endpoint, dict) else endpoint
            for endpoint in endpoints
        ]
        for endpoint_value in endpoint_values:
            reject_url_credentials(endpoint_value)
        scope_target = next((item for item in endpoint_values if item), None)

        for endpoint, endpoint_value in zip(endpoints, endpoint_values):
            if isinstance(endpoint, dict):
                if endpoint_value and not _is_in_scope(endpoint_value, scope_target, config):
                    scanned.append(_failed_scan(endpoint_value, "Endpoint is outside the authorized scope"))
                    continue
                if endpoint_value and endpoint.get("reachable") and isinstance(endpoint.get("headers"), dict):
                    scanned.append(_scan_response_headers(endpoint_value, endpoint["headers"]))
                    continue
                if endpoint_value:
                    scanned.append(_failed_scan(endpoint_value, endpoint.get("error") or "Discovery could not reach this endpoint"))
                    continue
            if endpoint_value is None:
                continue
            scanned.append(_scan_single_endpoint(endpoint_value, config, logger, scope_target))

        summary = {
            "total_endpoints": len(scanned),
            "successful_scans": sum(1 for item in scanned if item.get("scan_status") == "completed"),
            "failed_scans": sum(1 for item in scanned if item.get("scan_status") != "completed"),
        }
        payload = {
            "target": scanned[0]["target"] if scanned else "Unknown target",
            "scan_status": "completed" if scanned else "failed",
            "error": None if scanned else "No endpoints to scan",
            "endpoints": scanned,
            "summary": summary,
        }
        _write_json("scan_result.json", payload)
        return payload

    reject_url_credentials(target)
    payload = _scan_single_endpoint(target, config, logger, target)
    _write_json("scan_result.json", payload)
    return payload


def _is_in_scope(endpoint, scope_target, config):
    if not scope_target:
        return False
    if not is_same_host_authorized(scope_target, config):
        return False
    try:
        return same_host_allowed(scope_target, endpoint, config)
    except ValueError:
        return False


def _failed_scan(target, error):
    headers = [
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Strict-Transport-Security",
        "Referrer-Policy",
        "Permissions-Policy",
        "Cross-Origin-Opener-Policy",
        "Set-Cookie",
    ]
    return {
        "target": target,
        "headers": {header: "NOT FOUND" for header in headers},
        "scan_status": "failed",
        "error": error,
    }
