import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"


def _log(logger, message, level="info"):
    if logger is None:
        return
    getattr(logger, level)(message)


def _write_json(filename, payload):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / filename
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return path


def _remediation_for_header(header_name, status):
    """Provide cautious, evidence-based remediation guidance for supported header observations."""
    if status == "NOT FOUND":
        instructions = {
            "Strict-Transport-Security": "Add Strict-Transport-Security with a reasonable max-age and, if appropriate, includeSubDomains so browsers enforce HTTPS consistently.",
            "Content-Security-Policy": "Define a restrictive Content-Security-Policy that limits script, style, and resource sources to trusted values.",
            "Permissions-Policy": "Restrict unused browser features with a least-privilege Permissions-Policy configuration.",
            "Referrer-Policy": "Set Referrer-Policy to a restrictive value such as strict-origin-when-cross-origin or no-referrer.",
            "Cross-Origin-Opener-Policy": "Configure a restrictive Cross-Origin-Opener-Policy that limits cross-origin window behavior as appropriate.",
            "X-Frame-Options": "Add X-Frame-Options with a restrictive value such as DENY or SAMEORIGIN to prevent framing where not required.",
            "X-Content-Type-Options": "Add X-Content-Type-Options: nosniff to reduce MIME confusion risks.",
            "Set-Cookie": "If cookies are used, configure them with Secure, HttpOnly, and SameSite attributes appropriate to the application.",
        }
        return instructions.get(header_name, "Review the configuration of this security header and align it with the application's least-privilege browser security settings.")
    if status == "WEAK VALUE":
        instructions = {
            "Strict-Transport-Security": "Review the Strict-Transport-Security policy and ensure it is configured with an appropriate max-age and only the required directives.",
            "Content-Security-Policy": "Tighten the Content-Security-Policy to remove overly broad sources or unsafe directives that weaken browser-side protections.",
            "Permissions-Policy": "Reduce unnecessary browser feature permissions and keep the Permissions-Policy limited to the application's actual needs.",
            "Referrer-Policy": "Use a stricter Referrer-Policy value that limits cross-site referrer leakage.",
            "Cross-Origin-Opener-Policy": "Restrict the Cross-Origin-Opener-Policy to a less permissive value that matches the application's needs.",
            "X-Frame-Options": "Use a more restrictive X-Frame-Options value such as DENY or SAMEORIGIN when framing is not required.",
            "X-Content-Type-Options": "Use a stricter value such as nosniff and verify that content-type handling is aligned with the application's requirements.",
            "Set-Cookie": "Review the cookie attributes and ensure Secure, HttpOnly, and SameSite are set to a least-privilege configuration appropriate to the application.",
        }
        return instructions.get(header_name, "Review this policy and tighten it to a least-privilege browser security configuration appropriate to the application.")
    return "No remediation required for this observation."


def _build_finding(endpoint_target, header_name, status):
    """Construct a single validation finding for one header on one endpoint."""
    if status in {"NOT FOUND", "WEAK VALUE"}:
        if header_name == "Set-Cookie":
            explanation = (
                "The Set-Cookie response header was not hardened with the expected cookie protection attributes. "
                "This is a configuration observation, not a confirmed vulnerability. "
                "It may reduce browser-side cookie protections or permit broader cross-site cookie behavior."
            ) if status == "WEAK VALUE" else (
                "The Set-Cookie response header was not detected in the HTTP response. "
                "This is a configuration observation, not a confirmed vulnerability. "
                "It may indicate limited cookie usage or weaker session protection."
            )
        else:
            explanation = (
                f"The {header_name} header was not detected in the HTTP response. "
                "This is a configuration observation, not a confirmed vulnerability. "
                "It may indicate weaker browser protections or missing defense-in-depth controls."
            ) if status == "NOT FOUND" else (
                f"The {header_name} header is present but its value appears weak or permissive. "
                "This is a configuration observation, not a confirmed vulnerability. "
                "It may reduce browser security protections or expose broader access than intended."
            )

        return {
            "Finding name": header_name,
            "Observation": f"{endpoint_target} - {header_name}: {status}",
            "Validation status": "Potential Finding",
            "Basic explanation": explanation,
            "Recommended remediation": _remediation_for_header(header_name, status),
            "Endpoint": endpoint_target,
        }

    return {
        "Finding name": header_name,
        "Observation": f"{endpoint_target} - {header_name}: {status}",
        "Validation status": "No issue found",
        "Basic explanation": f"The {header_name} header is present and appears to be configured.",
        "Endpoint": endpoint_target,
    }


def run_validation(scan_data, config=None, logger=None):
    """Validate scan findings without labeling them as confirmed vulnerabilities."""
    target = (scan_data or {}).get("target", "Unknown target")
    findings = []
    unvalidated_endpoints = []

    if isinstance((scan_data or {}).get("endpoints"), list):
        endpoints = (scan_data or {}).get("endpoints", [])
        for endpoint in endpoints:
            endpoint_target = endpoint.get("target") or endpoint.get("url") or target
            if endpoint.get("scan_status") == "failed":
                unvalidated_endpoints.append({
                    "endpoint": endpoint_target,
                    "scan_status": "failed",
                    "validation_status": "not_assessed",
                })
                continue
            for header_name, status in endpoint.get("headers", {}).items():
                findings.append(_build_finding(endpoint_target, header_name, status))

        if not endpoints and (scan_data or {}).get("scan_status") == "failed":
            unvalidated_endpoints.append({
                "endpoint": target,
                "scan_status": "failed",
                "validation_status": "not_assessed",
            })

        payload = {
            "target": target,
            "findings": findings,
            "validation_status": "completed",
            "endpoints": (scan_data or {}).get("endpoints", []),
            "unvalidated_endpoints": unvalidated_endpoints,
        }
        _write_json("validation_result.json", payload)
        _log(logger, f"Validation completed for {target}")
        return payload

    if (scan_data or {}).get("scan_status") == "failed":
        unvalidated_endpoints.append({
            "endpoint": target,
            "scan_status": "failed",
            "validation_status": "not_assessed",
        })
    else:
        for header_name, status in (scan_data or {}).get("headers", {}).items():
            findings.append(_build_finding(target, header_name, status))

    payload = {
        "target": target,
        "findings": findings,
        "validation_status": "completed",
        "unvalidated_endpoints": unvalidated_endpoints,
    }
    _write_json("validation_result.json", payload)
    _log(logger, f"Validation completed for {target}")
    return payload
